<?php
/**
* @version $Id: spanish.ignore.php Versión Formal Neutra 23.07.2007 Equipo de Traducción de la Comunidad Hispana de Joomla!.
* @translator:  TodosJuntos.org <www.todosjuntos.org>
* @package: Joomla!
* @copyright: Copyright (C) 2005 - 2009 TodosJuntos.org. All rights reserved - Todos los derechos reservados.
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License v2, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

$search_ignore[] = "el";
$search_ignore[] = "la";
$search_ignore[] = "lo";

$search_ignore[] = "yo";
$search_ignore[] = "tu";
$search_ignore[] = "él";
$search_ignore[] = "nos";
$search_ignore[] = "vos";
$search_ignore[] = "nosotros";
$search_ignore[] = "vosotros";
$search_ignore[] = "ella";
$search_ignore[] = "ellos";
$search_ignore[] = "ellas";

$search_ignore[] = "en";
$search_ignore[] = "al";
$search_ignore[] = "por";
$search_ignore[] = "como";
$search_ignore[] = "cómo";
$search_ignore[] = "de";
$search_ignore[] = "desde";
$search_ignore[] = "cabe";
$search_ignore[] = "donde";

$search_ignore[] = "qué";
$search_ignore[] = "que";

?>
