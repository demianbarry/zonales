<?php

define('SUCCESS',0,true);
define('ERROR',1,true);
define('WARNING',2,true);
define('INFO',3,true);
define('ACTION',4,true);

?>
