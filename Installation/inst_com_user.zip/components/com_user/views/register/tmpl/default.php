<?php echo $this->moduleregister;?>
