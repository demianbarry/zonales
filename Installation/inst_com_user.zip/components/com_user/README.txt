Instrucciones de intalacion
---------------------------

* Copie el directorio com_user en JPATH_ROOT/components.
  Si le pregunta si desea sobreescribir los archivos, indique que SI.

* Copie los archivos en libraries en los subdirectorios correspondientes
  de JPATH_LIBRARIES, como indica la ruta.

* Ejecute el script install.sql

* Copie el archivo es-ES.com_user.ini en JPATH_ROOT/language/es-ES
  reemplazando el existente