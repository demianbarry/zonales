DROP TABLE IF EXISTS `#__aapu_attribute_class` ;
DROP TABLE IF EXISTS `#__aapu_data_types` ;
DROP TABLE IF EXISTS `#__aapu_attributes` ;
DROP TABLE IF EXISTS `#__aapu_attribute_entity` ;
