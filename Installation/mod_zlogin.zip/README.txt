Instrucciones de instalacion
----------------------------

* Copiar el archivo webtoolkit.js en JPATH_ROOT/media/system/js