<?php
/**
 * YOOtheme template
 *
 * @author yootheme.com
 * @copyright Copyright (C) 2008 YOOtheme Ltd & Co. KG. All rights reserved.
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

?>
<jdoc:include type="component" />