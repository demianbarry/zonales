<?php if ($showMessage): ?>
	<a class=pending-notice href="index.php?option=com_alias&view=alias">
            <?php echo $message ?>
        </a>
<?php endif ?>
