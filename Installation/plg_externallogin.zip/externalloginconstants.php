<?php
define('EXTERNAL_ID', 'externalid',true);
define('STATUS', 'status',true);
define('Auth_SUCCESS', 0, true);
define('Auth_CANCEL', 1,true);
define('Auth_FAILURE', 2,true);
define('PROVIDER', 'provider',true);
define('MESSAGE','message',true);

?>
