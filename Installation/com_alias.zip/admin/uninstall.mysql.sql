DROP TABLE IF EXISTS `#__alias`;
DROP TABLE IF EXISTS `#__providers`;
DROP TABLE IF EXISTS `#__protocol_types`;