# DROP TABLE IF EXISTS `#__custom_properties` ;
# DROP TABLE IF EXISTS `#__custom_properties_fields` ;
# DROP TABLE IF EXISTS `#__custom_properties_values` ;
