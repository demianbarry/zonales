<?php

if (!defined('SUCCESS')) define('SUCCESS',0,true);
if (!defined('ERROR')) define('ERROR',1,true);
if (!defined('WARNING')) define('WARNING',2,true);
if (!defined('INFO')) define('INFO',3,true);
if (!defined('ACTION')) define('ACTION',4,true);

?>
