&nbsp;
<p class="<?php echo $class ?>">
    <img class="image" src="<?php echo $icon ?>" alt="<?php echo $messageType ?>"/>
    <?php echo $message ?>
</p>
