<?php

/**
 * @author Azamat Tokhtaev
 * @copyright 2007
 */

defined("_JEXEC") or die('Restricted Access');
jimport('joomla.event.plugin');

class plgSystemJcAcl extends JPlugin
{

	var $_user = null;

	function plgSystemJcAcl(&$subject)
	{
		parent::__construct($subject);
		// load plugin parameters
		$this->_plugin = JPluginHelper::getPlugin('system', 'jcacl');
		$this->_params = new JParameter($this->_plugin->params);

		$acl = &JFactory::getACL();
		$db = &JFactory::getDBO();
		$session = &JFactory::getSession();
		$my = &$session->get('user');
		if ($my == null)
		{
			return;
		}
		$usertype = strtolower($my->usertype);
		if ($usertype != 'super administrator' && $usertype!= 'registered' && $usertype != 'author' && $usertype!='editor'
		&& $usertype != 'publisher' && $usertype != 'manager' && $usertype != 'administrator')
		{
			$user2 = &JUser::getInstance($my->id);
			$groupName = strtolower($user2->usertype);
			$groupId = $user2->gid;

			$sql = "SELECT `parent_id` FROM #__core_acl_aro_groups WHERE `id` = {$user2->gid}";
			$db->setQuery($sql);
			$parent_id = (int)$db->loadResult();
			$sql = "SELECT `id`, `name` FROM #__core_acl_aro_groups WHERE `parent_id` = {$parent_id} ORDER BY `id` LIMIT 1";
			$db->setQuery($sql);
			$toChange = $db->loadObject();
			//print "<pre>";
			foreach ($acl->acl as $value) {
				//print_r($value);

				if ($value[3] == strtolower($toChange->name))
				{
					$acl->addACL($value[0], $value[1], $value[2], $groupName, $value[4], $value[5], $value[6]);
				}

			}
			//print "</pre>";
			$my->usertype = $groupName;
			$my->gid =$groupId;

		}

	}

	function onAfterRoute()
	{
		$my = &JFactory::getUser();
		if ($my->id==62){ return; }
		global $mainframe;
		$blocks = $this->jcAclGetBlocks();

		if(!$blocks) return;
		foreach ($blocks as $toDoBlock)
		{

			parse_str($toDoBlock->value, $toBlock);
			$out = 0;
			foreach ($toBlock AS $key => $value)
			{
				if ($key == 'itemid') {$key = ucfirst($key);}


				if (strpos( $value,","))
				{
					$value = explode(",",$value);

					if (in_array(JRequest::getVar($key), $value)){++$out;}
				}
				else
				{
					if(JRequest::getVar($key) == $value) {++$out;}
				}
			}


			if($out == count($toBlock))
			{

				JError::raiseWarning(500, JText::_("You don't have enough rights to do this action"));
				$referer = $_SERVER['HTTP_REFERER'];
				if ($referer!=''){ $mainframe->redirect($referer); 		return;}
				else 						 { $mainframe->redirect('index.php'); return;}

			}

		}

	}

	function jcAclGetBlocks()
	{
		$my = &JFactory::getUser();
		$option = JRequest::getVar('option');
		$database = & JFactory::getDBO();
		$userid = (int)$my->get('id');
		$groupid = (int)$my->get('gid');

		$userid   = (intval($userid)>0)  ? $userid  : -1;
		$groupid  = (intval($groupid)>0) ? $groupid : -1;
		if ($userid != -1)
		{
			$sql = "SELECT * FROM #__jcacl_block_list WHERE `option` = '{$option}' AND (user_id = $userid)";
			$database->setQuery($sql);
			$blocks = $database->loadObjectList();
			if (count($blocks))
			{
				return $blocks;
			}
		}
		if ($groupid != -1)
		{
			$sql = "SELECT * FROM #__jcacl_block_list WHERE `option` = '{$option}' AND group_id = $groupid";
			$database->setQuery($sql);
			$blocks = $database->loadObjectList();

			if (count($blocks))
			{
				return $blocks;

			}

		}
	}
}