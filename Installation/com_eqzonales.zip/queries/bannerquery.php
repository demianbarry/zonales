<?php

jimport('solr.query');

class BannerQuery implements SolrQuery{

    function getQuery() {
        ;
    }
}

?>
