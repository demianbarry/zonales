CREATE TABLE IF NOT EXISTS `#__jcacl_block_list` (
  `id` int(11) NOT NULL auto_increment,
  `option` varchar(50) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `group_id` int(50) NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`)
); 