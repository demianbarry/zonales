<?php
//admin.jaccess.php
/**
 * @author Azamat
 * @copyright 2007
 */
defined('_JEXEC') or die('Restricted Access');
jimport('joomla.filesystem.file');
require_once (JPATH_COMPONENT_ADMINISTRATOR.DS.'controller.php');
if ($controller = JRequest::getVar('controller'))
{
  $path = JPATH_COMPONENT . DS . 'controllers' . DS . $controller . '.php';
  if (file_exists($path))
  {
    require_once ($path);
    $classname = 'jcACLController'.ucfirst($controller);
  }

} else {
    $path = JPATH_COMPONENT.DS.'controllers'.DS.'components.php';
    require_once ($path);
    $classname = 'jcACLControllerComponents';
}

require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'xajax.php');

$controller = new $classname();
// Perform the Request task
$controller->execute(JRequest::getVar('task'));
// Redirect if set by the controller
$controller->redirect();


?>