<?php
/**
 * @author Azamat Tokhtaev (AzMan)
 * @createDate 28/1/2008
 * @email krik123@gmail.com
 */
defined('_JEXEC') or die('Restricted Access');
?>
<form name="adminForm" action="index.php" method='post' >
	<table width="100%">
	<tr>
  	<td valign="top">
  	<div style="color:red;">*<?php echo JText::_('Note: When deleting groups all users belonging to that groups automatically moved to group which ther were inherited from!'); ?></div>
    	<table class="adminlist">
    	 <thead>
    	   <tr>
    	     <th width="2%" class="title"><?php echo JText::_('NUM');?></th>
    	     <th width="1%" class="title">
					 <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->gtree); ?>);" /></th>
    	     <th class="title"><?php echo JText::_('Name');?></th>
    	     <th class="title" width="7%"><?php echo JText::_('Is Core');?></th>
    	     <th width="2%" class="title"><?php echo JText::_('ID');?></th>
    	   </tr>
    	 </thead>
    	 <tbody>
    	   <?php
    	   $k = 0;
    	   $i = 0;
    	    foreach ($this->gtree as $row)
    	    {
    	     ?>
    	     <tr class="row<?php echo $k;?>">
    	       <td><?php echo $i+1;?></td>
    	       <td><?php echo $row->value>30 ?  JHTML::_('grid.id', $i, $row->value ) : "<input type='checkbox' disabled='disabled'>" ;?></td>
    	       <td><?php echo $row->text;?></td>
    	       <td><?php
    	           if ($row->value<30)
    	           {
    	             echo JText::_('Core');
    	           }
    	           ?>
    	       </td>
    	       <td><?php echo $row->value; ?></td>
    	     </tr>
    	     <?php
           $k = 1 - $k;
           $i++;
    	    }
    	   ?>
    	 </tbody>
    	</table>
    </td>
  <tr>
 </table>

<input type='hidden' name='option' value="com_jcacl">
<input type='hidden' name='boxchecked' value="0">
<input type='hidden' name='controller' value="usrgroups">
<input type='hidden' name='task' value="">
<input type='hidden'name="newGroup" id="newGroup" value="">
<input type='hidden'name="gid" id="gid" value="">
<?php echo JHTML::_( 'form.token' ); ?>
 </form>