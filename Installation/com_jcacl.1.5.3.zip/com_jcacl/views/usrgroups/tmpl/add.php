<div><fieldset>
<legend><?php echo JText::_('Create New'); ?></legend>
<?php echo JText::_("Name");?>: <input type="text" size="20" name="newGroup" id="newGroup">
<button id="creteGroup" onclick="if (document.getElementById('gid').value=='' || document.getElementById('newGroup').value.length<3){return false;}
            else{window.top.document.getElementById('gid').value=document.getElementById('gid').value;
            window.top.document.getElementById('newGroup').value=document.getElementById('newGroup').value;
            window.top.submitbutton('creategroup');
            window.top.setTimeout('window.parent.document.getElementById(\'sbox-window\').close()', 700);}">
<?php echo JText::_('Create');?></button>
<br/>
<?php echo JText::_("Based on"); ?>:<br>
<?php echo $this->gtree['gid']; ?>
</fieldset>
</div>