<?php
defined('_JEXEC') or die();
?>
<form action="index.php" method="post" name="adminForm" autocomplete="off" >
<div>
<fieldset>
<legend><?php echo JText::_("Choose a target group"); ?></legend>
<?php echo $this->list_gid;?>
</fieldset>
</div>
<?php print $this->cid; ?>
<input type="hidden" name="option" value="<?php echo $option; ?>" />
<input type="hidden" name="controller" value="usrgroups" />
<input type="hidden" name="users" value="<?php echo $this->cid; ?>" />
<input type="hidden" name="task" value="" />
</form>