<?php

/**
 * @author Azamat Tokhtaev (AzMan)
 * @createDate 28/1/2008
 * @email krik123@gmail.com
 */

defined('_JEXEC') or die();

jimport('joomla.application.component.view');


class jcACLViewUsrGroups extends JView
{
	function display($tpl = null)
	{
		switch ($this->getLayout())
		{
			case 'add':
				$acl = &JFactory::getACL();
				$gtree = $acl->get_group_children_tree( null, 'USERS', false );
				$total = count($gtree);
				for ( $i = 0; $i<$total; $i++)
				{
					if ($gtree[$i]->value >= 30 || $gtree[$i]->value==29 || $gtree[$i]->value == 25)
					{
						unset($gtree[$i]);
					}
				}
				$lists['gid'] 	= JHTML::_('select.genericlist',   $gtree, 'gid', 'size="10"', 'value', 'text' );
				$this->assignRef('gtree', $lists);
				parent::display();
				break;
			case 'move':
				JToolBarHelper::title(JText::_('Moving Users'), 'generic.png');
				JToolBarHelper::cancel('cancelmove');
				$html = "<a href=\"javascript:void(0);\" onclick=\"javascript:".
								"if (document.getElementById('gid').value==''){alert('".JText::_("Select group first!")."');".
								 " return false;} else submitbutton('move');\" class=\"toolbar\">";
				$html .= "<span class='icon-32-move'  type=\"Standard\">";
				$html .= "</span>";
				$html .= JText::_('Commit Move');
				$html .= "</a>";
				$bar = & JToolBar::getInstance();
				$bar->appendButton( 'Custom', $html, 'close' );
				$acl = &JFactory::getACL();
				$user = &JFactory::getUser();
				$gtree = $acl->get_group_children_tree( null, 'USERS', false );
				$list_gid   = JHTML::_('select.genericlist',   $gtree, 'gid', 'size="10"', 'value', 'text'  );
				$cid = (JRequest::getVar('cid'));
				$this->assignRef('cid', $cid);
				$this->assignRef('list_gid', $list_gid);
				parent::display($tpl);
				break;

			default:
				JToolBarHelper::title(JText::_('Groups Management for JS Permission'), 'generic.png');

				$bar = & JToolBar::getInstance();
				$bar->appendButton( 'Popup', 'new', 'Add', 'index3.php?option=com_jcacl&controller=usrgroups&task=showadd', 600, 400 );
				JToolBarHelper::deleteListX();
				$acl = &JFactory::getACL();
				$gtree = $acl->get_group_children_tree( null, 'USERS', false );
				$user = &JFactory::getUser();
				$total = count($gtree);
				$gtreeCopy = $gtree;
				for ( $i = 0; $i<$total; $i++)
				{
					if ($gtree[$i]->value==30 or $gtree[$i]->value==29)
					{
						unset($gtree[$i]);
					}
				}

				$this->assignRef('gtree', $gtree);
				parent::display($tpl);
				break;
		}
	}
}

?>