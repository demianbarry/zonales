<?php
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view');
jimport('joomla.application.component.model');
class jcACLViewUsers extends JView
{
	function display($tpl = null)
	{
		global $mainframe, $option;
    if($this->getLayout() == 'editusers') {
			$this->_displayEditUsersForm($tpl);
			return;
		}
		JToolBarHelper::title(   JText::_( 'JoomSuite Permission' ), 'generic.png' );
    JToolBarHelper::help( 'license', 'com_jcacl' );
    $xml_data = $this->get('Xml');
 		$users = $this->get('Users');
    $this->assignRef('users', $users);
		$this->assignRef('components',$xml_data);
		parent::display($tpl);
	}

	function _displayEditUsersForm($tpl)
	{
	  $xml_data = $this->get('OneXml');
	  JToolBarHelper::title(   JText::_( 'Permisions Manager for Users' )."({$xml_data->_info['name']})", 'generic.png' );
	  JToolBarHelper::back();
		JToolBarHelper::help( 'license', 'com_jcacl' );
		$xml = $this->get('oneXml');
		$users = $this->get('Users');
    $blocked = $this->get('Blocked');
    $mygroup = $this->get('MyGroup');
    $this->assignRef('blocked', $blocked);
		$this->assignRef('users', $users);
		$this->assignRef('component', $xml);
		$this->assignRef('mygroup', $mygroup);
	  parent::display($tpl);
	}
}
?>