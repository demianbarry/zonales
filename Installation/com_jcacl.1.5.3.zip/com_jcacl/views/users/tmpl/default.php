<?php
defined('_JEXEC') or die('Restricted Access');
//print_r($this->users);
?>
<h3>Select a component</h3>
<form name='adminForm' method="post" action='index.php' id='adminForm' enctype="multipart/form-data">
<table width='100%' class="adminlist">
  <thead>
  <tr class='title'>
    <th  nowrap='nowrap' width='1%'>
     #
    </th>
    <th class='title' width='1%' nowrap='nowrap'>
      <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->components); ?>);" />
    </th>
    <th class='title' >
      <?php print JText::_('Name'); ?>
    </th>
    <th class='title' >
      <?php print JText::_('Option'); ?>
    </th>
    <th class='title' nowrap='nowrap' width='1%'>
      <?php print JText::_('Version'); ?>
    </th>
    <th class='title' nowrap='nowrap' width='1%'>
      <?php print JText::_('Author'); ?>
    </th>
    <th class='title' nowrap='nowrap' width='1%'>
      <?php print JText::_('E-mail'); ?>
    </th>
    <th class='title' nowrap='nowrap'>
      <?php print JText::_('Site'); ?>
    </th>
  </tr>
  </thead>
  <?php
    $counter = 1;
    $k = 0;
    $i = 0;
    if (count($this->components)>0)
    {
    foreach ($this->components as $component)
    {
     ?>
     <tr class='row<?php print $k;?>'>
      <td nowrap='nowrap' >
        <?php print $counter; ?>
      </td>
      <td>
       <?php echo JHTML::_('grid.id', $i, $component->_file );?>
      </td>
      <td nowrap='nowrap'>
        <a href = '#' onclick="jcaclSubmit('<?php print $component->_file; ?>');">
        <?php print $component->_name; ?></a>
      </td>
      <td nowrap='nowrap'>
        <?php print $component->_option; ?>
      </td>
      <td nowrap='nowrap' align="center" width="1%">
        <?php print $component->_version; ?>
      </td>
      <td nowrap='nowrap' align="center" width="1%">
        <?php print $component->_author; ?>
      </td>
      <td nowrap='nowrap' align="center" width="1%">
        <?php print $component->_email; ?>
      </td>
      <td nowrap='nowrap' align="center" width="1%">
        <?php print $component->_site; ?>
      </td>
     </tr>
     <?php
     $counter++;
     $k = 1 - $k;
     $i++;
    }
    }
  ?>
</table>
<fieldset style="width:200px;">
  <legend><?php print JText::_('Selected users') ?></legend>
  <?php foreach($this->users as $user)
  {
    print "<br>{$user->username}";
  }
  ?>
</fieldset>
<?php
$i = 0;
foreach($this->users as $user)
{
  print "<input type='hidden' name='users[]' value = '{$user->id}'>\n";
  $i++;
}
?>
<input type='hidden' name='value' value='' />
<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="controller" value="users" />
<input type="hidden" name="task"  value="" />
<input type="hidden" name="boxchecked" value="0" />
</form>
<script language="javascript">
function jcaclSubmit(xml)
{
  form = document.adminForm;
  form.task.value = 'editusers';
  form.controller.value = 'users';
  form.value.value = xml;
  submitbutton('editusers');
}
</script>
