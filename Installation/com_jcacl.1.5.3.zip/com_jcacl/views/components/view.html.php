<?php
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view');
class jcACLViewComponents extends JView
{
	function display($tpl = null)
	{
		global $mainframe, $option;
		switch (JRequest::getVar('currentLay'))
  	{
  	  case 'setPermissions':
  	    $this->_displayEditForm($tpl);
  			return;
  		break;
  	  case 'addXml':
  	    $this->_displayAddForm($tpl);
  			return;
  		break;
  	  case 'editXml':
  	    $this->_displayEditXml($tpl);
  			return;
  		break;
  	  case 'editXmlVar':
  	    $this->_displayEditXmlVar($tpl);
  			return;
  		break;
  	  case 'addXmlVar':
  	    $this->_displayAddXmlVar($tpl);
  	    return;
  	  break;
  	  case 'editXmlDesc':
  	    $this->_displayEditXmlDesc($tpl);
  	    return;
  	  break;
  	  case 'moveVars':
  	    $this->_displayMoveXmlVars($tpl);
  	    return;
  	  break;
  	  case 'editXmlGroup':
  	    $this->_displayEditXmlGroup($tpl);
  	    return;
  	  break;
  	  case 'copyVars':
  	    $this->_displayCopyVars($tpl);
  	    return;
  	  break;
  	  default:
  		JToolBarHelper::title(   JText::_( 'JoomSuite Permission' ), 'generic.png' );
      JToolBarHelper::editListX('edit', JText::_("Set Permissions"));
  		JToolBarHelper::editListX('edit_xml');
   		JToolBarHelper::addNewX();
  		JToolBarHelper::deleteList();
  		JToolBarHelper::help( 'license', 'com_jcacl' );
  		$xml_data = $this->get('Xml');
  		$this->assignRef('components',$xml_data);
  		parent::display($tpl);
  		break;
		}
	}
	function _displayEditForm($tpl)
	{
	  $xml_data = $this->get('OneXml');
	  JToolBarHelper::title(   JText::_( 'Permisions Manager' )."({$xml_data->_info['name']})", 'generic.png' );
	  JToolBarHelper::back();
		JToolBarHelper::help( 'license', 'com_jcacl' );
		$groups = $this->get('Groups');
		$mygroup = $this->get('MyGroup');
		$frontend = 0;
		$backend  = 0;
		$i = 0;
    for ($i = 0; $i<count($groups); $i++)
    {
      if ($groups[$i]->value==29 ||$groups[$i]->value==30)
      {
        if ($groups[$i]->value==30)
        {
           $frontend=$i-1;
        }
        unset($groups[$i]);
      }
    }
    $backend = $i-$frontend;
		$blocked_list = $this->get('BlockedItems');
    $this->assignRef('frontend', $frontend);
    $this->assignRef('backend', $backend);
    $this->assignRef('component', $xml_data);
    $this->assignRef('mygroup', $mygroup);
    $this->assignRef('groups', $groups);
    $this->assignRef('blocked', $blocked_list);

	  parent::display($tpl);
	}

	function _displayAddForm($tpl)
	{
	  JToolBarHelper::title(   JText::_( 'Add Component' ), 'generic.png' );
	  $html = "<a href=\"javascript:void(0);\" onclick=\"if (jsaclCheckValues()) {submitbutton('createNewXml');}\" class=\"toolbar\">";
    $html .= "<span class=icon-32-save type=\"Standard\">";
    $html .= "</span>";
    $html .= JText::_('Save');
    $html .= "</a>";
    $bar = & JToolBar::getInstance();
    $bar->appendButton( 'Custom', $html, 'close' );
	  JToolBarHelper::back();
	  $layout = JRequest::getVar('currentLay');
	  $file = JRequest::getVar('file');
	  $this->assignRef('file', $file);
	  $this->assignRef('layout', $layout);
	  parent::display($tpl);
	}

	function _displayEditXml($tpl)
	{
	  $name = JRequest::getVar('cid');
	  $name = $name[0];
	  $xml = $this->get('oneXml');
	  if (empty($name) or $name=='')
	  {
	    $name = JRequest::getVar('file');
	  }
	  JToolBarHelper::title(  JText::_('Edit XML ').$xml->_name, 'generic.png' );
    JToolBarHelper::back(JText::_('Back'), 'index.php?option=com_jcacl');
    JToolBarHelper::divider();
	  JToolBarHelper::custom('copyVars', 'copy', 'copy', JText::_('Copy'), true);
    JToolBarHelper::custom('moveVars', 'move', 'copy', JText::_('Move'), true);
    JToolBarHelper::divider();
	  JToolBarHelper::custom('editDesc', 'edit', 'edit', JText::_('Edit Desc.'), false);
	  JToolBarHelper::addNewX('addXmlVar');
	  JToolBarHelper::editListX('editXmlVar');
	  JToolBarHelper::deleteListX('Delete', 'deleteXmlVar');



	  $this->assignRef('file', $name);
	  $this->assignRef('xml', $xml);
	  parent::display($tpl);
	}

	function _displayEditXmlVar($tpl)
	{

	  JToolBarHelper::title(  JText::_('Edit Variable'), 'generic.png' );
	  JToolBarHelper::save('save_var');
	  JToolBarHelper::apply('apply_var');
	  JToolBarHelper::cancel('cancelEditVar');
	  $file = JRequest::getVar('file');
	  $variable = $this->get("Variable");
	  $xmlFile = $this->get('OneXml');
	  $this->assignRef('file', $file);
	  $this->assignRef('xmlFile', $xmlFile);
	  $this->assignRef('variable', $variable);
	  parent::display($tpl);
	}

	function _displayAddXmlVar($tpl)
	{
    JToolBarHelper::title(  JText::_('Edit Variable'), 'generic.png' );
    $html = "<a href=\"javascript:void(0);\" onclick=\"if (jsaclCheckValues()) {submitbutton('saveNewVar');} \" class=\"toolbar\">";
    $html .= "<span class=icon-32-save type=\"Standard\">";
    $html .= "</span>";
    $html .= JText::_('Save');
    $html .= "</a>";
    $bar = & JToolBar::getInstance();
    $bar->appendButton( 'Custom', $html, 'close' );
    $html = "<a href=\"javascript:void(0);\" onclick=\"if (jsaclCheckValues()) {submitbutton('applyNewVar');}\" class=\"toolbar\">";
    $html .= "<span class=icon-32-apply type=\"Standard\">";
    $html .= "</span>";
    $html .= JText::_('Apply');
    $html .= "</a>";
    $bar->appendButton( 'Custom', $html, 'close' );
	  JToolBarHelper::cancel('cancelNewVar');
	  $file = JRequest::getVar('file');
    $xmlFile = $this->get('OneXml');

	  $this->assignRef('file', $file);
	  $this->assignRef('xmlFile', $xmlFile);
	  parent::display($tpl);
	}

	function _displayEditXmlDesc($tpl)
	{
	  $xml= $this->get('OneXml');
	  JToolBarHelper::title(  JText::_('Edit Descriptions for ').$xml->_name, 'generic.png' );
	  $html = "<a href=\"javascript:void(0);\" onclick=\"if (jsaclCheckValues()) {submitbutton('applyXmlDesc');}\" class=\"toolbar\">";
    $html .= "<span class=icon-32-apply type=\"Standard\">";
    $html .= "</span>";
    $html .= JText::_('Apply');
    $html .= "</a>";
    $bar = & JToolBar::getInstance();
    $bar->appendButton( 'Custom', $html, 'close' );
    $html = "<a href=\"javascript:void(0);\" onclick=\"if (jsaclCheckValues()) {submitbutton('saveXmlDesc');}\" class=\"toolbar\">";
    $html .= "<span class=icon-32-save type=\"Standard\">";
    $html .= "</span>";
    $html .= JText::_('Save');
    $html .= "</a>";
    $bar->appendButton( 'Custom', $html, 'close' );
	  JToolBarHelper::cancel('cancelEditDesc');
	  $layout = JRequest::getVar('currentLay');
	  $file = JRequest::getVar('file');
	  $this->assignRef('xml', $xml);
	  $this->assignRef('layout', $layout);
	  $this->assignRef('file', $file);
	  parent::display($tpl);
	}

	function _displayMoveXmlVars($tpl)
	{
	  $xml = $this->get('OneXml');
	  JToolBarHelper::title(  JText::_('Move >>'), 'generic.png' );
	  JToolBarHelper::custom('doMove', 'move', 'move', JText::_("Move"), false);
	  JToolBarHelper::cancel('cancelEditVar');
	  $varsToMove = $this->get('VarsToMove');
	  $filename = JRequest::getVar('file');
	  $this->assignRef('xmlFile', $xml);
	  $this->assignRef('variables', $varsToMove);
	  $this->assignRef('file', $filename);
	  parent::display($tpl);
	}

	function _displayEditXmlGroup($tpl)
	{
	  $filename = JRequest::getVar('file');
    $groupName = JRequest::getVar('group');
    $groupName = $groupName[0];
    JToolBarHelper::title(  JText::_('Change name for Group: ').$groupName, 'generic.png' );
    JToolBarHelper::save('saveGroupName');
    JToolBarHelper::apply('applyGroupName');
    JToolBarHelper::cancel('cancelGroupName');
    $this->assignRef('oldGroupName', $groupName);
    $this->assignRef('file', $filename);
    parent::display($tpl);
	}

	function _displayCopyVars()
	{
    $filename = JRequest::getVar('file');
    JToolBarHelper::title(  JText::_('Copy variables '), 'generic.png' );
    JToolBarHelper::custom('doCopy', 'copy', 'copy', JText::_("Copy"), false);
    JToolBarHelper::cancel('cancelEditVar');
    $varsToCopy = JRequest::getVar('variable');
    $xmlFile = $this->get('OneXml');
    $this->assignRef('xmlFile', $xmlFile);
    $this->assignRef('file', $filename);
    $this->assignRef('variables', $varsToCopy);
    parent::display($tpl);
	}
}
?>