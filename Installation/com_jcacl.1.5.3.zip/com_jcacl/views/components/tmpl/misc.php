<?php
defined('_JEXEC') or die('Restricted Access');
?>

<form name='adminForm' method="post" action="index.php" id="adminForm">

<?php
switch (JRequest::getVar('currentLay'))
{
  case 'moveVars':
  ?>
    <fieldset>
    <legend><?php echo JText::_('Move To:'); ?></legend>
    <select name='whereTo'>
    <?php
      foreach ($this->xmlFile->_groups as $group)
      {
        echo "<option value='$group'>$group</option>\n";
      }
    ?>
    </select>
    </fieldset>
    <fieldset>
      <legend><?php echo JText::_('Variables to move');?></legend>
      <?php
      foreach ($this->variables as $var)
      {
        $var2 = explode("::", $var);
        echo $var2[1].", ";
        echo "<input type='hidden' name='variable[]' value='{$var}'>";
      }
      ?>
    </fieldset>

  <?php
  break;
  case 'editXmlGroup':
    ?>
    <fieldset>
      <legend><?php echo JText::_("New Group Name");?>:</legend>
      <input type="text" size='25' name="newGroupName">
      <input type="hidden" name="oldGroupName" value="<?php echo $this->oldGroupName; ?>">
    </fieldset>
    <?php
  break;

  case 'copyVars':
    ?>
    <fieldset>
    <legend><?php echo JText::_("Where to Copy");?>:</legend>
    <select name='whereTo'>
    <?php
      foreach ($this->xmlFile->_groups as $group)
      {
        echo "<option value='$group'>$group</option>\n";
      }
    ?>
    </select>
   </fieldset>
    <fieldset>
      <legend><?php echo JText::_('Variables to copy');?></legend>
      <?php
      foreach ($this->variables as $var)
      {
        $var2 = explode("::", $var);
        echo $var2[1].", ";
        echo "<input type='hidden' name='variable[]' value='{$var}'>";
      }
      ?>
    </fieldset>
    <?php
  break;
  default:
  break;
}
?>


<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="controller" value="components" />
<input type="hidden" name="task"  value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="file" value="<?php echo $this->file; ?>">
</form>