<?php
defined('_JEXEC') or die('Restricted Access');
?>
<style type="text/css">
table.adminlist th.jcaclgroupname
{
text-align: center;
background-color: #f0f0f0;
background-image: none;
background-repeat: repeat;
background-attachment: scroll;
background-x-position: 0%;
background-y-position: 0%;
color: #666666;
border-bottom-width: 1px;
border-bottom-style: solid;
border-bottom-color: #999999;
border-left-width: 1px;
border-left-style: solid;
border-left-color: #ffffff;
}
table.adminlist th.jcaclvariable
{

}
</style>
<div style='width:500px;'>
  <div class="t">
    <div class="t">
      <div class="t">
      </div>
    </div>
  </div>
  <div class='m'>
  <table width='100%'>
  <tbody>
    <tr>
      <td width="1%" nowrap='nowrap'>
      <strong><?php echo JText::_("Name");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_name;?>
      </td>
    </tr >
    <tr>
    <td width="1%" nowrap='nowrap'>
     <strong> <?php echo JText::_("Option");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_option;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap'>
      <strong><?php echo JText::_("Version");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_version;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap'>
     <strong> <?php echo JText::_("Author");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_author;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap'>
     <strong> <?php echo JText::_("Author E-mail");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_email;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap'>
     <strong> <?php echo JText::_("Site");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_site;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap'>
      <strong><?php echo JText::_("Copyright");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_copyright;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap'>
      <strong><?php echo JText::_("License");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_license;?>
      </td>
    </tr>
    <tr>
    <td width="1%" nowrap='nowrap' valign="top">
      <strong><?php echo JText::_("Description");?>:</strong>
      </td>
      <td>
        <?php print $this->xml->_description;?>
      </td>
    </tr>
    </tbody>
  </table>
  </div>
  <div class='b'>
    <div class='b'>
      <div class='b'>
      </div>
    </div>
  </div>
</div>
<br />
<form name='adminForm' method="post" action="index.php" id="adminForm">
<table class="adminlist" width='100%'>
<?php
foreach($this->xml->_items as $groupName => $group)
{
?>
  <tr>
    <th class="jcaclgroupname"><input type ="checkbox" id='<?php echo $groupName.'0';?>' value='<?php echo $groupName;?>'
                                name="group[]" onClick="isChecked(this.checked);"></th>
    <th class="jcaclgroupname" colspan="10" style="text-align:left;">
      <?php echo $groupName;?>
    </th>
  </tr>
<?
  $k = 0;
  $i = 1;
  foreach ($group as $item)
  {
    ?>
    <tr class="<?php print "row$k";?>">

      <td width="1%"><input type ='checkbox' name='<?php echo "variable[]";?>' id='<?php echo $groupName.$i;?>'
                      value="<?php print $groupName.'::'.$item['name'];?>" onClick="isChecked(this.checked);"></td>
      <th class="jcaclvariable" width="1%" nowrap="nowrap">
       <?php echo $item['name'];?>
      </th>

      <?php
      foreach ($item['attributes'] as $key => $val)
      {
        print "<td nowrap='nowrap'>$key=$val</td>";

      }
      ?>
    </tr>
    <?php
    $k = 1 - $k;
    $i++;
  }
}
?>
</table>
<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="controller" value="components" />
<input type="hidden" name="task"  value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="file" value="<?php echo $this->file; ?>">
</form>
<script language="javascript">
function jcaclGroupItems( name , count)
{
  if (document.getElementById(name).checked)
  {
    for( var i = 0; i<count; i++)
    {
      var current = document.getElementById(name+i);
      current.checked=true;
    }
  }
  else
  {
    for( var i = 0; i<count; i++)
    {
      var current = document.getElementById(name+i);
      current.checked=false;
    }
  }
}
</script>
