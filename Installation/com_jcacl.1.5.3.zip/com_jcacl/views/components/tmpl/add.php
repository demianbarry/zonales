<?php
defined('_JEXEC') or die('Restricted Access');
error_reporting(0);
?>
<form name='adminForm' method="post" action='index.php' id='adminForm'>
<fieldset>
<legend><?php echo JText::_('Description Information');?></legend>
<table width='600'>
<?php
if ($this->layout=='addXml')
{
?>
<tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('Name of the file');?>:*
    </td>
    <td>
    <input type='text' size='20' name='c[fname]' id='xmlFname'>
    <span style="color:red;"><?php echo JText::_("(a-z 0-9, without extension)");?></span>
    </td>
  </tr>
<?php  } ?>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('Name');?>:*
    </td>
    <td>
    <input type='text' size='20' name='c[name]' id='xmlName' value='<?php echo $this->xml->_name;?>'>
    <?php echo JText::_("Name that will represent the component that this file is made for.");?>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('option(com_something)');?>:*
    </td>
    <td>
    <input type='text' size='20' name="c[option]" id="xmlOption" value='<?php echo $this->xml->_option; ?>'>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('Author');?>:
    </td>
    <td>
    <input type='text' size='30' name='c[author]' value = '<?php echo $this->xml->_author; ?>'>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('Author e-mail');?>:
    </td>
    <td>
    <input type='text' size='30' name="c[email]" value = '<?php echo $this->xml->_email; ?>'>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('Author web site');?>:
    </td>
    <td>
    <input type='text' size='30' name="c[site]" value = '<?php echo $this->xml->_site; ?>'>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('License');?>:
    </td>
    <td>
    <input type='text' size='30' name="c[license]" value = '<?php echo $this->xml->_license; ?>'>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap'>
    <?php echo JText::_('Copyright');?>:
    </td>
    <td>
    <input type='text' size='30' name="c[copyright]" value = '<?php echo $this->xml->_copyright; ?>'>
    </td>
  </tr>
  <tr>
    <td width='1%' nowrap='nowrap' valign="top">
    <?php echo JText::_('Description');?>:
    </td>
    <td>
    <textarea cols="30" rows="3" name="c[description]"><?php echo $this->xml->_description;?></textarea>
    </td>
  </tr>
</table>
</fieldset>
<?php
echo $this->layout;
if ($this->layout=='editXmlDesc'){
echo "<input type='hidden' name='file' value='{$this->file}'>";
echo "<input type='hidden' name='c[fname]' value='{$this->file}' id='xmlFname'>";
}
?>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="controller" value="components" />
<input type="hidden" name="task"  value="" />
<input type="hidden" name="boxchecked" value="0" />
</form>

<script language="javascript">
function jsaclCheckValues()
{
  var name = document.getElementById('xmlName');
  var option = document.getElementById('xmlOption');
  var fname = document.getElementById('xmlFname');
  var ret = false;
  if (name.value=='')
  {
    alert("<?php echo JText::_("Enter the name to represent the component that this file is written for!"); ?>");
     ret = false;
  }
  if (fname.value=='')
  {
    alert("<?php echo JText::_("Enter the name of the xml file (without extension)!"); ?>");
     ret = false;
  }
  else if (option.value=='')
  {
    alert("<?php echo JText::_("Enter the option for the component!"); ?>");
     ret = false;
  }
  else { ret = true;}
  return ret;
}
</script>