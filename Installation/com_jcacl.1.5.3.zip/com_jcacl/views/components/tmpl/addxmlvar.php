<?php
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name='adminForm' id="adminForm">
<fieldset>
  <legend><?php echo JText::_('Enter URL here') ?></legend>
  <input type='text' size='100' name='url'>
  <input type='button' value="Process URL" onclick="xajax_jcaclprocess_url(xajax.getFormValues('adminForm', 0 ,'url'));">
</fieldset>
<fieldset>
  <legend><?php echo JText::_("Group"); ?></legend>
  <div>
    <b><?php echo JText::_("Member of ")?></b>
    <select id='groupNames' name='currentGroupName' onchange="jsaclCheckSelect(this.value);">
      <option selected='selected' value=''></option>
      <?php
      foreach ($this->xmlFile->_groups as $g)
      {
        echo "<option value='$g'>$g</option>";
      }
      echo "<option value='new'>".JText::_("Create new")."</option>";
      ?>
    </select>
      <input type='text' name='newGroupName' value='' style="display:none;" size='20' id='newGroupName'>
  </div>
</fieldset>
<script language="javascript">
function jsaclCheckSelect(value)
{
  var field = document.getElementById('newGroupName');
  if (value=='new')
  {
    field.disabled=false;
    field.style.display = 'inline';
  }
  else
  {
    field.disabled=true;
    field.style.display = 'none';
  }
}
</script>

<table class="adminlist" id='adminlist'>

  <thead>
    <tr>
      <th style="text-align:left;">
      <?php echo JText::_("Variable");?> : <input type="text" size="20" maxlength="60" name="newVarname" id="newVarname">
      </th>
    </tr>
  </thead>

  <tbody id='table'>

    </tbody>
</table>

<div id='addAttr'><a href="javascript:jsaclAddAttr(<?php echo 1?>)">[+]Add</a></div>
<input type='hidden' id='urlcounter' name = 'urlcounter' value='<?php echo 1;?>'>
<input type="hidden" name="varname" value="none">
<input type="hidden" name="groupname" value="none">
<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="controller" value="components" />
<input type="hidden" name="task"  value="" />
<input type="hidden" name="file" value="<?php echo $this->file; ?>">
</form>
<script language="javascript">

function jsaclAddAttr( counter)
{

  var table = document.getElementById('table');
  var tr = document.createElement("TR");
  var td = document.createElement("TD");
  var urlcounter = document.getElementById('urlcounter');


    td.innerHTML = "<input type='text' name = 'var["+counter+"][key]' size = '20' value=''> = "
                    +"<input name='var["+counter+"][value]' type='text' size = '20' value=''> "
                    +"<a href =\"javascript:jsaclRemove("+counter+" , '')\">[-]Remove</a>";
    td.setAttribute('id', 'xmlvar'+counter);
    tr.setAttribute("class", "");
    tr.setAttribute("id", "row"+counter);
    tr.appendChild(td);

    table.appendChild(tr);
    link = document.getElementById('addAttr');
    link.innerHTML = "<a href=\"javascript:jsaclAddAttr("+(counter+1)+")\">[+]Add</a>";
    urlcounter.value = counter+1;


}

function jsaclXajaxAddAttr( counter, key, val)
{

  var table = document.getElementById('table');
  var tr = document.createElement("TR");
  var td = document.createElement("TD");
  var urlcounter = document.getElementById('urlcounter');

  if (!jsaclExists(counter, key, val)){
    td.innerHTML = "<input type='text' name = 'var["+counter+"][key]' size = '20' value='"+key+"'> = "
                    +"<input name='var["+counter+"][value]' type='text' size = '20' value='"+val+"'> "
                    +"<a href =\"javascript:jsaclRemove("+counter+" , '')\">[-]Remove</a>";
    td.setAttribute('id', 'xmlvar'+counter);
    tr.setAttribute("class", "");
    tr.setAttribute("id", "row"+counter);
    tr.appendChild(td);

    table.appendChild(tr);
    link = document.getElementById('addAttr');
    link.innerHTML = "<a href=\"javascript:jsaclAddAttr("+(counter+1)+")\">[+]Add</a>";
    urlcounter.value = counter+1;
  }

}

function jsaclRemove(counter, attr)
{
  var table = document.getElementById('table');
  var tr = document.getElementById('row'+counter);
  if (attr!='')
  {
    var hidden1 = document.createElement("INPUT");
    var hidden2 = document.createElement("INPUT");
    var hidden3 = document.createElement("INPUT")
    hidden1.setAttribute('name', "var["+counter+"][key]");
    hidden1.setAttribute('value', "");
    hidden1.setAttribute('type', "hidden");
    hidden2.setAttribute('name', "var["+counter+"][value]");
    hidden2.setAttribute('value', "");
    hidden2.setAttribute('type', "hidden");
    hidden3.setAttribute('name', "var["+counter+"][old]");
    hidden3.setAttribute('value', attr);
    hidden3.setAttribute('type', "hidden");
    table.appendChild(hidden1);
    table.appendChild(hidden2);
    table.appendChild(hidden3);
  }
  table.removeChild(document.getElementById('row'+counter));
}

function jsaclRefreshTr()
{
  var k = 0;
  var table = document.getElementById('table');
  var elements = table.getElementsByTagName('TR');
  for(var i=0; i<elements.length; i++)
  {
   elements[i].className = "row"+k;
   k = 1- k;
  }
}

function jsaclExists(counter ,key, value)
{
  var ret = false
  var table = document.getElementById('table');
  var elements = table.getElementsByTagName("INPUT");
  for (var i = 0; i < elements.length; i++)
  {
    if (elements[i].type=='hidden')
    {
      continue;
    }
    for (var j=0; j<=counter+1; j++)
    {
      if (elements[i].name=="var["+j+"][key]" && elements[i].value==key)
      ret = true;
    }
  }
  return ret;
}

function jsaclCheckValues()
{
  var ret = true;
  var name = document.getElementById('newVarname');
  var group = document.getElementById('groupNames');
  var newGroup = document.getElementById('newGroupName');

  if (name.value=='')
  {
    alert("<?php echo JText::_("You have to specify the name of the variable!"); ?>");
    ret = false;
  }

  if (group.value=='')
  {
    alert("<?php echo JText::_("You have to specify the group for the variable!"); ?>");
    ret = false;
  }

  if (group.value=='new' && newGroup.value=='')
  {
    alert("<?php echo JText::_("You have to specify the group for the variable!"); ?>");
    ret = false;
  }

  return ret;
}
</script>
