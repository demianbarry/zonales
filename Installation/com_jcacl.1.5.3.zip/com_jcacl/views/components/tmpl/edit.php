<?php
defined('_JEXEC') or die('Restricted Access');
/*print "<pre>";
print_r($this->groups);
print "</pre>";*/
$acl = &JFactory::getACL();
?>

<style type='text/css'>
  .jcACLTitle
  {
    font-size:13px;
    background-color:#e7e7e7;
  }
  .jcACLSub
  {
  background-color:#ededed;
  }
  .jcACLBorder
  {
  background-color:#e7e7e7;
  }
</style>
<table class='adminlist'>

<thead>
  <tr>
    <td style='background-color:white;'>
    </td>
    <th colspan="<?php echo $this->frontend; ?>">
      <?php print JText::_('Public Frontend');?>
    </th>
    <td class='jcACLBorder'>
    </td>
    <th colspan='<?php echo $this->backend; ?>'>
    <?php print JText::_('Public Backend');?>
    </th>
  </tr>


<?php

    print "<tr>";
    print "<td style='background-color:white; border:0;'></td>";
    $i = 0;
    foreach($this->groups as $ugroup)
    {
       $ugroup->text = preg_replace("/\&nbsp\;|\.|\-/",'', $ugroup->text);
       if ($i==$this->frontend)
       {
         print "<td class='jcACLBorder'></td>";

       }


      {
        print "<th class='jcACLSub'>{$ugroup->text}</th>";
      }
      $i++;
    }
    print "</tr>";
    print "</thead>";
  foreach($this->component->_groups as $group)
  {
?>
  <tr>
    <th colspan="8" class='jcACLTitle'>
      <?php print $group;?>
    </th>
  </tr>


<?php

    $k = 0;
    foreach($this->component->_items[$group] as $parameters)
    {
      $text='';
      $b=0;
      foreach($parameters['attributes'] as $key=>$value)
      {
        $text .='&'.$key.'='.$value;
      }
      ?>
       <tr class="row<?php print $k;?>">
        <td>
          <?php print $parameters['name'];?>
        </td>
        <?php
        $i=0;

        foreach($this->groups as $ugroup)
        {
          $hash = md5($b.$text);
          if ($i==$this->frontend)
          {
          print "<td style='background-color:#ededed; border:0;'></td>";
          }
          $some = 0;
          foreach ($this->blocked as $block)
          {
            if ($block->option == $this->component->_option and $block->group_id == $ugroup->value and $block->value == $text)
            {
              print "<td align='center'><a href='#' onClick=\"xajax_jcaclblock({$ugroup->value},'{$text}', '{$this->component->_option}', '{$hash}', $this->mygroup); document.getElementById('{$hash}').src='components/com_jcacl/images/loader.gif';\">"
                   ."<img src='components/com_jcacl/images/unchecked.gif' id='{$hash}'></a></td>";
              $some++;
              break;
            }

          }
          if ($some==0)
          {
            print "<td align='center'><a href='#' onClick=\"xajax_jcaclblock({$ugroup->value},'{$text}', '{$this->component->_option}', '{$hash}', $this->mygroup); document.getElementById('{$hash}').src='components/com_jcacl/images/loader.gif';\">"
                   ."<img src='components/com_jcacl/images/checked.gif' id='{$hash}'></a></td>";
          }

          $i++;
          $b++;
        }
        $k = 1 - $k;
        ?>
      </tr>
      <?php
    }
  }
?>
</table>
