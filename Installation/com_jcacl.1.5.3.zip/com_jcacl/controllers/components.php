<?php
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');
class jcACLControllerComponents extends jcACLController
{
	function __construct()
	{
		parent::__construct();

		$this->registerTask( 'edit', 'edit' );
		$this->registerTask( 'install', 'install' );
		$this->registerTask( 'edit_xml', 'editXml' );
		$this->registerTask( 'editXmlVar', 'editXmlVar' );
		$this->registerTask( 'createNewXml', 'createXml' );
		$this->registerTask( 'save_var', 'save_var' );
		$this->registerTask( 'cancelEditVar', 'cancelEditVar' );
		$this->registerTask( 'deleteXmlVar', 'deleteXmlVar' );
		$this->registerTask( 'addXmlVar', 'addXmlVar' );
		$this->registerTask( 'apply_var', 'applyXmlVar' );
		$this->registerTask( 'cancelNewVar', 'cancelEditVar' );
		$this->registerTask( 'saveNewVar', 'saveNewVar' );
		$this->registerTask( 'applyNewVar', 'applyNewVar' );
		$this->registerTask( 'editDesc', 'editDesc' );
		$this->registerTask( 'saveXmlDesc', 'saveXmlDesc' );
		$this->registerTask( 'applyXmlDesc', 'applyXmlDesc' );
		$this->registerTask( 'cancelEditDesc', 'cancelEditDesc' );
		$this->registerTask( 'moveVars', 'moveVars' );
		$this->registerTask( 'doMove', 'doMove' );
		$this->registerTask( 'saveGroupName', 'saveGroupName' );
		$this->registerTask( 'applyGroupName', 'applyGroupName' );
		$this->registerTask( 'cancelGroupName', 'cancelEditVar' );
		$this->registerTask( 'copyVars', 'copyVars' );
		$this->registerTask( 'doCopy', 'doCopyVars' );

	}
	#*************************************************************
	function display()
	{
		JRequest::setVar('view', 'components');
		parent::display();
	}

	function add()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'add');
		JRequest::setVar('currentLay', 'addXml');
		parent::display();
	}

	function edit()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'edit');
		JRequest::setVar('currentLay', 'setPermissions');
		parent::display();

	}

	function createXml()
	{
		$comp = JRequest::getVar('c');
		$comp['fname'] = strtolower($comp['fname']);

		if (JFile::exists('components/com_jcacl/xml/'.$comp['fname'].'.xml'))
		{
			$this->setRedirect("index.php?option=com_jcacl&controller=components&task=add", JText::_("The file with the same name already exists!"), 'notice');
		}

		$comp['option'] = strtolower(trim($comp['option']));
		$text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$text.= "\n<component option='{$comp['option']}'>";
		$text.= "\n\t<name><![CDATA[{$comp['name']}]]></name>";
		$text.= "\n\t<author><![CDATA[{$comp['author']}]]></author>";
		$text.= "\n\t<version>1.0</version>";
		$text.= "\n\t<email><![CDATA[{$comp['email']}]]></email>";
		$text.= "\n\t<site><![CDATA[{$comp['site']}]]></site>";
		$text.= "\n\t<license><![CDATA[{$comp['license']}]]></license>";
		$text.= "\n\t<copyright><![CDATA[{$comp['copyright']}]]></copyright>";
		$text.= "\n\t<description><![CDATA[{$comp['description']}]]></description>";
		$text.= "\n</component>";

		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$comp['fname'].'.xml', $text))
		{
			$this->setRedirect("index.php?option=com_jcacl&controller=components", JText::_("The file was created successfuly") );
		}
		else
		{
			$this->setRedirect("index.php?option=com_jcacl&controller=components&task=add", JText::_("Error Could not create file!"),'notice' );
		}



	}

	function remove()
	{

		require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'xml_parser.php');
		$filename = JRequest::getVar('cid', null, 'default', 'array');
		jimport('joomla.filesystem.file');

		foreach($filename as $file)
		{
			$xmlFile = new jsACL($file);
			$option = $xmlFile->_option;
			$database = &JFactory::getDBO();
			$sql = "DELETE FROM #__jcacl_block_list WHERE `option` = '{$option}'";
			$database->setQuery($sql);
			$database->query();
			JFile::delete(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$file);
			$this->setRedirect('index.php?option=com_jcacl&controller=components', JText::_('The XML file and All the records related to this file were deleted.'));
		}
	}

	function install()
	{
		jimport('joomla.filesystem.file');
		$post = JRequest::get('files');
		$file = $post['xmlFile'];
		if (strrchr($file['name'], '.')!='.xml')
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components', JText::_("The file extention is not valid!"), 'notice');
		}

		if (JFile::exists(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$file['name']))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components', JText::_("The file already exists!"), 'notice');
		}
		$src = $file['tmp_name'];


		$dst = JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$file['name'];

		if(JFile::upload($src, $dst))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components', JText::_("The file was uploaded Successfuly!"));
		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components', JText::_("Error Occured while uploading the file!", 'notice'));
		}

	}
	#*************************************************************

	function editXml()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'edit_xml');
		JRequest::setVar('currentLay', 'editXml');
		parent::display();
	}

	function editXmlVar()
	{
		JRequest::setVar('view', 'components');
		$group =JRequest::getVar('group');
		if (count($group)>0)
		{
			JRequest::setVar('editGroup', '1');
			JRequest::setVar('layout', 'misc');
			JRequest::setVar('currentLay', 'editXmlGroup');
		}
		else
		{
			JRequest::setVar('layout', 'edit_xml_var');
			JRequest::setVar('currentLay', 'editXmlVar');
		}



		parent::display();
	}

	function addXmlVar()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'addxmlvar');
		JRequest::setVar('currentLay', 'addXmlVar');
		parent::display();
	}

	function saveNewVar()
	{
		$db           = &JFactory::getDBO();

		$varName      = JRequest::getVar('newVarname');
		$attrs        = JRequest::getVar('var');
		$filename     = JRequest::getVar('file');
		$groupName    = JRequest::getVar('currentGroupName');
		$newGroupName = JRequest::getVar('newGroupName');

		$xmlFile = new JSimpleXML();
		if (!$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not read data from XML file!"), 'notice');
		}
		require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'xml_parser.php');

		if ($groupName=='new')
		{
			jsACL::createGroup($xmlFile, $newGroupName);
			$groupName = $newGroupName;
		}

		if (jsACL::isVariabeExist($xmlFile, $varName, $groupName))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("This same variable for this group already exists!"), 'notice');
			return;
		}


		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}

		jsACL::addVariable($xmlFile, $varName, $groupName, $attrs);

		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();

		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}
	}




	function applyNewVar()
	{
		$varName = JRequest::getVar('newVarname');
		$attrs = JRequest::getVar('var');
		$filename = JRequest::getVar('file');
		$groupName = JRequest::getVar('currentGroupName');
		$newGroupName = JRequest::getVar('newGroupName');

		$xmlFile = new JSimpleXML();
		if (!$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not read data from XML file!"), 'notice');
		}
		require_once('components/com_jcacl/helpers/xml_parser.php');

		if ($groupName=='new')
		{
			jsACL::createGroup($xmlFile, $newGroupName);
			$groupName = $newGroupName;
		}

		if (jsACL::isVariabeExist($xmlFile, $varName, $groupName))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=addXmlVar&file='.$filename,
			JText::_("This same variable for this group already exists!"), 'notice');
			return;
		}
		jsACL::addVariable($xmlFile, $varName, $groupName, $attrs);
		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}


		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();

		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename."&variable[]={$groupName}::{$varName}",
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename."&variable[]={$groupName}::{$varName}",
			JText::_("Could not Update XML File!"), 'notice');
		}

	}



	function save_var()
	{
		$filename = JRequest::getVar('file');
		$groupName = JRequest::getVar('groupname');
		$variableName = JRequest::getVar('varname');
		$xmlFile = new JSimpleXML();
		$attrs  = JRequest::getVar('var');
		if (!$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not read data from XML file!"), 'notice');
		}

		require_once('components/com_jcacl/helpers/xml_parser.php');
		$currentGroup = JRequest::getVar('currentGroupName');
		if ($currentGroup!=$groupName and $currentGroup!='new')
		{

			jsACL::changeVarGroupName($xmlFile, $groupName, $currentGroup, $variableName, $attrs);
			$groupName = $currentGroup;
		}
		else if ($currentGroup!=$groupName and $currentGroup=='new')
		{
			$newGroup = JRequest::getVar('newGroupName');
			jsACL::createGroup($xmlFile, $newGroup);
			jsACL::changeVarGroupName($xmlFile, $groupName, $newGroup, $variableName, $attrs);
		}
		jsACL::changeVariableAttributes($xmlFile, $variableName, $groupName, $attrs);

		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}


		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();

		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}

	}

	function cancelEditVar()
	{
		$this->setRedirect("index.php?option=com_jcacl&controller=components&task=edit_xml&file=".JRequest::getVar('file'));
	}

	function deleteXmlVar()
	{
		$groups = JRequest::getVar('group');
		$variables = JRequest::getVar('variable');
		$filename = JRequest::getVar('file');

		if (count($groups)>0 or count($variables)>0)
		{

			require_once('components/com_jcacl/helpers/xml_parser.php');
			$xmlFile = new JSimpleXML();
			$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename);


		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}
		if (count($groups)>0)
		{
			foreach ($groups as $group)
			{
				jsACL::deleteGroups($xmlFile, $group);

			}
		}
		if (count($variables)>0)
		{
			foreach ($variables as $var)
			{

				$var = @explode("::" ,$var);
				//print $var[0]."==".$var[1];

				jsACL::deleteVars($xmlFile, $var[1], $var[0]);
			}
		}
		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}
		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&cid[0]='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}
		//print "<pre>";
		//print htmlentities($body);
		//print "</pre>";
	}


	function applyXmlVar()
	{
		$filename = JRequest::getVar('file');
		$groupName = JRequest::getVar('groupname');
		$variableName = JRequest::getVar('varname');
		$xmlFile = new JSimpleXML();
		$attrs  = JRequest::getVar('var');
		if (!$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename.'&groupname='.$groupName.'&variable[]='.$variableName,
			JText::_("Could not read data from XML file!"), 'notice');
		}

		require_once('components/com_jcacl/helpers/xml_parser.php');
		$currentGroup = JRequest::getVar('currentGroupName');
		if ($currentGroup!=$groupName and $currentGroup!='new')
		{

			jsACL::changeVarGroupName($xmlFile, $groupName, $currentGroup, $variableName, $attrs);
			$groupName = $currentGroup;
		}
		else if ($currentGroup!=$groupName and $currentGroup=='new')
		{
			$newGroup = JRequest::getVar('newGroupName');
			jsACL::createGroup($xmlFile, $newGroup);
			jsACL::changeVarGroupName($xmlFile, $groupName, $newGroup, $variableName, $attrs);
			$groupName = $newGroup;
		}
		jsACL::changeVariableAttributes($xmlFile, $variableName, $groupName, $attrs);

		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}

		jimport('joomla.filesystem.file');
		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();
		//print "<pre>";
		//print htmlentities($body);
		//print "</pre>";

		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename."&variable[]={$groupName}::{$variableName}",
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename."&variable[]={$groupName}::{$variableName}",
			JText::_("Could not Update XML File!"), 'notice');
		}
	}

	#*************************************************************
	function editDesc()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'add');
		JRequest::setVar('currentLay', 'editXmlDesc');
		parent::display();
	}


	function saveXmlDesc()
	{

		$descriptions = JRequest::getVar('c');
		$xmlFile = new JSimpleXML();
		$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$descriptions['fname']);
		require_once('components/com_jcacl/helpers/xml_parser.php');
		foreach($descriptions as $key => $desc)
		{
			jsACL::changeDesc($xmlFile, $key, $desc);
		}
		//print "<pre>";
		//print_r($xmlFile->document);
		//print htmlentities($xmlFile->document->toString());
		//print $xmlFile->document->_attributes['option'];//=trim(strtolower($descriptions['option']));
		//print "</pre>";
		$xmlFile->document->_attributes['option']=trim(strtolower($descriptions['option']));
		jimport('joomla.filesystem.file');

		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$descriptions['fname'],$heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$descriptions['fname'],
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$descriptions['fname'],
			JText::_("Could not Update XML File!"), 'notice');
		}
	}


	function applyXmlDesc()
	{
		$descriptions = JRequest::getVar('c');
		$xmlFile = new JSimpleXML();
		$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$descriptions['fname']);
		require_once('components/com_jcacl/helpers/xml_parser.php');
		foreach($descriptions as $key => $desc)
		{
			jsACL::changeDesc($xmlFile, $key, $desc);
		}
		//print "<pre>";
		//print htmlentities($xmlFile->document->toString());
		//print "</pre>";
		$xmlFile->document->_attributes['option']=trim(strtolower($descriptions['option']));


		$heading = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body = $xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$descriptions['fname'],$heading.$body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editDesc&file='.$descriptions['fname'],
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editDesc&file='.$descriptions['fname'],
			JText::_("Could not Update XML File!"), 'notice');
		}
	}

	function cancelEditDesc()
	{
		$filename = JRequest::getVar('file');
		$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename);
	}

	#*************************************************************

	function moveVars()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'misc');
		JRequest::setVar('currentLay', 'moveVars');
		parent::display();
	}

	function copyVars()
	{
		JRequest::setVar('view', 'components');
		JRequest::setVar('layout', 'misc');
		JRequest::setVar('currentLay', 'copyVars');
		parent::display();
	}

	function doMove()
	{
		$filename = JRequest::getVar('file');
		$vars = JRequest::getVar('variable');
		$whereTo = JRequest::getVar('whereTo');
		$xmlFile = new JSimpleXML();
		$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename);
		require_once('components/com_jcacl/helpers/xml_parser.php');
		foreach ($vars as $var)
		{
			$var = explode("::", $var);
			//print_r($var);
			jsACL::changeVarGroupName($xmlFile, $var[0], $whereTo, $var[1]);
		}
		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}


		$body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body.=$xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename,
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}

	}

	function doCopyVars()
	{
		$filename = JRequest::getVar('file');
		$vars = JRequest::getVar('variable');
		$whereTo = JRequest::getVar('whereTo');
		$xmlFile = new JSimpleXML();
		$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename);
		require_once('components/com_jcacl/helpers/xml_parser.php');
		foreach ($vars as $var)
		{
			$var = explode("::", $var);
			jsACL::copyVar($xmlFile, $var[0], $whereTo, $var[1]);

		}

		$option = trim($xmlFile->document->_attributes['option']);
		if ($this->deleteFromDB($option))
		{
			JError::raiseNotice(100, JText::_("All permissions for this component were deleted. Please reconfigure permissions"));
		}


		$body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body.=$xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename,
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}

	}
	#*************************************************************

	function saveGroupName()
	{
		$newGroupName = JRequest::getVar('newGroupName');
		$oldGroupName = JRequest::getVar('oldGroupName');
		$filename = JRequest::getVar('file');

		require_once('components/com_jcacl/helpers/xml_parser.php');
		$xmlFile = new JSimpleXML();
		$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename);

		jsACL::changeGroupName($xmlFile, $oldGroupName, $newGroupName);


		$body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body.=$xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename,
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=edit_xml&file='.$filename,
			JText::_("Could not Update XML File!"), 'notice');
		}
	}

	function applyGroupName()
	{
		$newGroupName = JRequest::getVar('newGroupName');
		$oldGroupName = JRequest::getVar('oldGroupName');
		$filename = JRequest::getVar('file');

		require_once('components/com_jcacl/helpers/xml_parser.php');
		$xmlFile = new JSimpleXML();
		$xmlFile->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename);

		jsACL::changeGroupName($xmlFile, $oldGroupName, $newGroupName);


		$body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
		$body.=$xmlFile->document->toString();
		if (JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'xml'.DS.$filename, $body))
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename."&group[]={$newGroupName}",
			JText::_("The XML File Was Updated Successfuly!"));

		}
		else
		{
			$this->setRedirect('index.php?option=com_jcacl&controller=components&task=editXmlVar&file='.$filename."&group[]={$newGroupName}",
			JText::_("Could not Update XML File!"), 'notice');
		}
	}

	#*************************************************************

	function deleteFromDB($option)
	{
		$db = &JFactory::getDBO();
		$sql = "DELETE FROM #__jcacl_block_list WHERE `option` = '{$option}'";
		$db->setQuery($sql);
		if ($db->query())
		return true;
	}
}


?>