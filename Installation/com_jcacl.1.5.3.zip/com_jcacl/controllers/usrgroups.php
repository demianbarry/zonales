<?php
error_reporting(E_ALL);
class jcACLControllerUsrGroups extends jcACLController
{
  function __construct()
  {

    /*$this->registerTask('unblock', 'unblock');
    $this->registerTask('logout', 'logout');*/
    parent::__construct();
    $this->registerTask('creategroup', 'creategroup');
    $this->registerTask('showmove', 'showmove');
    $this->registerTask('move', 'move');
    $this->registerTask('showadd', 'showadd');
  }

  function display()
  {
    JRequest::setVar( 'view'  , 'usrgroups');
    parent::display();
  }

  function creategroup()
  {
    $me = &JFactory::getUser();
    $gid = JRequest::getVar('gid');
    $newGroup = JRequest::getVar('newGroup');
    if ( ( $gid == 25 ) && ( $me->get( 'gid' ) != 25 ) )
    {
      $msg = JText::_( 'You cannot create a group based on super administrator group' );
      $this->setRedirect('index.php?option=com_jcacl&controller=usrgroups', $msg, 'notice');
    } else if (( $gid == 24 ) && ( $me->get( 'gid' ) >= 24 ))
    {
      $msg = JText::_( 'You cannot crete groups higher then or equal to yours' );
      $this->setRedirect('index.php?option=com_jcacl&controller=usrgroups', $msg, 'notice');
    }

    $db = &JFactory::getDBO();
    $sql  = "SELECT * FROM #__core_acl_aro_groups WHERE `id` = $gid";
    $db->setQuery($sql);
    $inherit = $db->loadObject();
    $sql = "SELECT MAX(`id`) as `id`  FROM #__core_acl_aro_groups";
    $db->setQuery($sql);
    $maxId = $db->loadResult();
    if ($maxId < 31)
    {
      $sql = "INSERT INTO #__core_acl_aro_groups VALUES(31, $inherit->parent_id, '{$newGroup}', $inherit->lft, $inherit->rgt, '{$newGroup}')";
    }
    else
    {
      $sql = "INSERT INTO #__core_acl_aro_groups VALUES(NULL, $inherit->parent_id , '{$newGroup}', $inherit->lft, $inherit->rgt, '{$newGroup}')";
    }
    $db->setQuery($sql);
    $db->query();

    $msg = JText::_( 'The new group was successfuly created' );
    $this->setRedirect('index.php?option=com_jcacl&controller=usrgroups', $msg);
  }

  function remove()
  {
    $cid = JRequest::getVar('cid', array());
    $my = &JFactory::getUser();
    $mygid = &JUser::getInstance($my->id);
    $mygid = $mygid->gid;
    if (@in_array($mygid, $cid))
    {
      $msg = JText::_( 'You cannot delete the group that you belong to' );
      $this->setRedirect('index.php?option=com_jcacl&controller=usrgroups', $msg, 'notice');
    }
    $or = '';
    $db = &JFactory::getDBO();
    $sql = "SELECT `parent_id` FROM #__core_acl_aro_groups WHERE `id` = {$my->gid}";
    $db->setQuery($sql);
    $myParent = $db->loadResult();
    //print $myParent;
    foreach ($cid as $key => $c)
    {
      if ($key == 0) { $or = " WHERE `id` = $c"; }
      else           { $or.=" OR `id` = $c"; }
    }
    $sql = "SELECT `id`,`parent_id`, `name` FROM #__core_acl_aro_groups".$or;
    $db->setQuery($sql);
    $toDel = $db->loadObjectList();
    /*print "<pre>";
    print_r($toDel);
    print "</pre>";
    exit;*/
    $note = '';
    switch ($myParent)
    {
      case '30'://29,20, 18, 19
      $allowed = array(29, 20, 19, 18); // allowed parent ids
      break;
      case '23':
        $allowed = array(30 ,29, 20, 19, 18); // allowed parent ids
        break;
      case '24':
        $allowed = array(24, 23,30 ,29, 20, 19, 18); // allowed parent ids
        break;
      default:
        //must not enter here
        break;
    }
    $total = count($toDel);
    for ($i = 0; $i<$total; $i++)
    {
      if (!@in_array($toDel[$i]->parent_id, $allowed))
      {
        unset($toDel[$i]);
        //$note .= "\n".sprintf(JText::_("The table %s was not deleted"), $toDel[$i]->name);
      }
    }
    if (count($toDel)>0)
    {
      foreach ($toDel as $val)
      {
        $sql = "SELECT `id`, `name` FROM #__core_acl_aro_groups WHERE `parent_id` = {$val->parent_id} ORDER BY `id` LIMIT 1";
        $db->setQuery($sql);
        $fatherGroup = $db->loadObject();
        $sql = "DELETE FROM #__core_acl_aro_groups WHERE `id` = {$val->id} LIMIT 1";
        $db->setQuery($sql);
        $db->query();
        $sql = "SELECT `id` FROM #__users WHERE `gid` = {$val->id}";
        $db->setQuery($sql);
        $user_ids = $db->loadResultArray();

        if (count($user_ids)>0){
          $sql = "UPDATE #__users SET `gid` = {$fatherGroup->id}, `usertype` = '{$fatherGroup->name}' WHERE `gid` = {$val->id}";
          $db->setQuery($sql);
          $db->query();
          $or = '';
          foreach ($user_ids as $key => $id)
          {
            if ($key==0){$or=" WHERE `value` = $id";}
            else        {$or.=" OR `value` = $id";}
          }
          $sql = "SELECT `id` FROM #__core_acl_aro".$or;
          $db->setQuery($sql);
          $aros = $db->loadResultArray();
          $or = '';
          foreach ($aros as $key => $aro)
          {
            if ($key==0){$or=" WHERE `aro_id` = $aro";}
            else        {$or.=" OR `aro_id` = $aro";}
          }
          $sql = "UPDATE #__core_acl_groups_aro_map SET `group_id` = {$fatherGroup->id}".$or;
          $db->setQuery($sql);
          $db->query();
        }
      }
    }

    $msg = JText::_( 'The group was successfuly Deleted' );
    $this->setRedirect('index.php?option=com_jcacl&controller=usrgroups', $msg);
  }

  function showmove()
  {
    JRequest::setVar( 'view'  , 'usrgroups');
    JRequest::setVar( 'layout'  , 'move');
    parent::display();
  }
  function move()
  {
    $target = JRequest::getVar('gid');
    $users_ids = JRequest::getVar('users');
    $db = &JFactory::getDBO();
    $me = &JFactory::getUser();
    $sql = "SELECT `parent_id`, `name` FROM #__core_acl_aro_groups WHERE `id` = {$me->gid}";
    $db->setQuery($sql);
    $myParent = $db->loadObject();

    switch ($myParent->parent_id)
    {
      case '30':
        $allowed = array(29, 20, 19, 18); // allowed parent ids
        break;
      case '23':
        $allowed = array(30 ,29, 20, 19, 18); // allowed parent ids
        break;
      case '24':
        $allowed = array(24, 23,30 ,29, 20, 19, 18); // allowed parent ids
        break;
      default: //must not enter here
      break;
    }
    $sql = "SELECT `parent_id`, `name` FROM #__core_acl_aro_groups WHERE `id` = {$target}";
    $db->setQuery($sql);
    $targetParent = $db->loadObject();
    if (!@in_array($targetParent->parent_id, $allowed))
    {
      $this->setRedirect('index.php?option=com_juser', JText::_("You can not move users to this group!"), 'notice');
    }
    if (preg_match("/:/", $users_ids)){$users_ids = explode(":", $users_ids); }
    else {$users_ids = array($users_ids);}
    //$users = array();
    foreach ($users_ids as $user) {
      $currentUser = &JUser::getInstance($user);
      $sql = "SELECT `parent_id` FROM #__core_acl_aro_groups WHERE `id` = {$currentUser->gid} LIMIT 1";
      $db->setQuery($sql);
      $currentParent = $db->loadResult();
      if (!@in_array($currentParent, $allowed)) { continue;}
      else
      {
        $sql = "SELECT `id` FROM #__core_acl_aro WHERE `value` = {$currentUser->id}";
        $db->setQuery($sql);
        $aro = $db->loadResult();
        $sql = "UPDATE #__core_acl_groups_aro_map SET `group_id` = {$target} WHERE `aro_id` = $aro";
        $db->setQuery($sql);
        $db->query();
        $sql = "UPDATE #__users SET `gid` = {$target}, `usertype` = '{$targetParent->name}' WHERE `id` = {$currentUser->id} LIMIT 1";
        $db->setQuery($sql);
        $db->query();

      }
    }
    $this->setRedirect('index.php?option=com_juser', JText::_("Users were Moved Successfuly"));
    /*print "<pre>";
    print_r($users);
    print "</pre>";*/
  }

  function showadd()
  {
    JRequest::setVar('view', 'usrgroups');
    JRequest::setVar('layout', 'add');
    parent::display();

  }
}
?>