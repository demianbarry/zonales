<?php
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');
class jcACLControllerUsers extends jcACLController
{
  function __construct()
  {
    parent::__construct();
     $this->registerTask( 'editusers', 'editUsers' );
  }
  function display()
  {
    JRequest::setVar('view', 'users');
    parent::display();
  }

  function editUsers()
  {
    JRequest::setVar('view', 'users');
    JRequest::setVar('layout', 'editusers');
    parent::display();
  }
}
?>