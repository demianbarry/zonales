<?php
//controller.php
/**
 * @author Azamat
 * @copyright 2008
 */

  defined('_JEXEC') or die('Restricted Access');
  jimport('joomla.application.component.controller');
  class jcACLController extends JController
  {
    function display()
    {
      parent::display();
    }
  }