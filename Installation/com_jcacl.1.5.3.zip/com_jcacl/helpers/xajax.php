<?php

/**
 * @author Azamat Tokhtaev
 * @copyright 2007
 */
/**
 *XAJAX FUNCTIONS WILL BE HERE
 *
 */
  defined('_JEXEC') or die('Restricted Access');

  require_once ('components/com_jcacl/xajax/xajax_core/xajax.inc.php');
  $xajax = new xajax('index3.php?option=com_jcacl&controller='.JRequest::getVar('controller'));
  $xajax->registerFunction('jcaclblock');
  $xajax->registerFunction('jcaclblockuser');
  $xajax->registerFunction('jcaclprocess_url');
  $xajax->registerFunction('jsacl_addattr');
  $xajax->registerFunction('jsacl_remattr');
  $xajax->processRequest();
  $xajax->printJavascript('components/com_jcacl/xajax/');

  /**
   * @param int $groupId
   * @param string of the variables $variables
   * @param options of the component $option
   * @param id of the image $imgId
   * @param current user group $mygroup
   */
  function jcaclblock($groupId, $variables, $option, $imgId, $mygroup)
  {
    $acl = &JFactory::getACL();
    $objResponse = new xajaxResponse;
    $database = &JFactory::getDBO();
    $user = &JFactory::getUser();

    $gtree = $acl->get_group_children_tree( null, 'USERS', false );
    $myGroupKey = 0;
    $targetGroupKey = 0;
    foreach ($gtree as $key => $gt)
    {
      if ($gt->value==$mygroup)
      {
        $myGroupKey = $key;
      }

      if ($gt->value == $groupId)
      {
        $targetGroupKey = $key;
      }

    }
    if ($myGroupKey<=$targetGroupKey && $user->id!=62)
    {
      $objResponse->alert("You dont't have the enough rights to edit this!");
      $sql = "SELECT COUNT(*) FROM #__jcacl_block_list WHERE `option` = '{$option}' AND `group_id` = '{$groupId}'"
            ." AND `value` = '{$variables}'";
      $database->setQuery($sql);
      $result = $database->loadResult();
      if ($result>0)
      {
        $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/unchecked.gif');
      }
      else
      {
        $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/checked.gif');
      }

      return $objResponse;
    }


    //$objResponse->alert($variables);
    $sql = "SELECT COUNT(*) FROM #__jcacl_block_list WHERE `option` = '{$option}' AND `group_id` = '{$groupId}'"
          ." AND `value` = '{$variables}'";
    $database->setQuery($sql);
    $result = $database->loadResult();
    if ($result>0)
    {
      $delete = "DELETE FROM #__jcacl_block_list WHERE `option` = '{$option}' AND `group_id` = '{$groupId}'"
                    ." AND `value` = '{$variables}'";

      $database->setQuery($delete);
      $database->query();
      $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/checked.gif');
    }
    else
    {
      $sql = "INSERT INTO #__jcacl_block_list(`option` ,`user_id` ,`group_id`,`value`)".
             " VALUES('{$option}', 0, $groupId, '{$variables}')";
      $database->setQuery($sql);
      $database->query();
      $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/unchecked.gif');
    }
    //$objResponse->alert(print_r($groups,true));
    return $objResponse;
  }

  function jcaclblockuser($user_id, $variables, $option, $imgId, $myGroup)
  {
    $objResponse = new xajaxResponse;
    $database = &JFactory::getDBO();
    $userInfo = JFactory::getUser($user_id);
    $userGroup= $userInfo->gid;
    if ($myGroup <= $userGroup)
    {
      $objResponse->alert(JText::_("You don't have enough rights to edit rights for this user!"));
      $sql = "SELECT COUNT(*) FROM #__jcacl_block_list WHERE `option` = '{$option}' AND `user_id` = '{$user_id}'"
            ." AND `value` = '{$variables}'";
      $database->setQuery($sql);
      $result = $database->loadResult();
      if ($result>0)
      {
        $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/unchecked.gif');
      }
      else
      {
        $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/checked.gif');
      }

      return $objResponse;
    }

    $sql = "SELECT COUNT(*) FROM #__jcacl_block_list WHERE `option` = '{$option}' AND `user_id` = {$user_id}"
          ." AND `value` = '{$variables}'";
    $database->setQuery($sql);
    $result = $database->loadResult();
    if ($result>0)
    {
      $delete = "DELETE FROM #__jcacl_block_list WHERE `option` = '{$option}' AND `user_id` = '{$user_id}'"
                    ." AND `value` = '{$variables}'";

      $database->setQuery($delete);
      $database->query();
      $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/checked.gif');
    }
    else
    {
      $sql = "INSERT INTO #__jcacl_block_list(`option` ,`user_id` ,`group_id`,`value`)".
             " VALUES('{$option}', {$user_id}, 0, '{$variables}')";
      $database->setQuery($sql);
      $database->query();
      $objResponse->assign($imgId, 'src', 'components/com_jcacl/images/unchecked.gif');
    }
    //$objResponse->alert(print_r($groups,true));
    return $objResponse;
  }

  function jcaclprocess_url($url)
  {

    $objResponse = new xajaxResponse();
    //$objResponse->alert(print_r($url, true));
    $counter = $url['urlcounter'];
    $url = parse_url($url['url']);
    $url= @explode("&",$url['query'] );
    $ret = array();
    if (count($url) > 0)
    {
      foreach ($url as $u)
      {
        $u = @explode("=",$u);
        $key = (@$u[0]);
        $val = (@$u[1]);
        if ($key=='option' or $key=='itemid') continue;

        //$text = "<tr><td id='xmlvar{$counter}'><input type='text' name = 'var[".$counter."][key]' size = '20' value='{$key}'> = "
        //          ."<input name='var[".$counter."][value]' type='text' size = '20' value='{$val}'> "
        //          ."<a href =\"javascript:jsaclRemove(".$counter." , '')\">[-]Remove</a></td></tr>";
        $objResponse->script("jsaclXajaxAddAttr($counter, '{$key}', '{$val}');");
        $counter++;
      }

    }

    $objResponse->assign('addAttr' , "innerHTML", "<a href=\"javascript:jsaclAddAttr(".($counter+1).")\">[+]Add</a>");
    $objResponse->assign('urlcounter','value', $counter+1);
    return $objResponse;
  }


 ?>