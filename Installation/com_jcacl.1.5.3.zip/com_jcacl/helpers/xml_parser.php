<?php
defined('_JEXEC') or die();

class jsACL
{
  var $_file = null; //File to parse
  var $_groups = array(); //list of the groups
  var $_items = array(); //array of items in the groups
  var $_info = null; //all The info about the xml file
  var $_name = null; //name of the component
  var $_option = null; //option i.e com_something
  var $_author = null; //Author
  var $_version = null; //version fo the
  var $_description = null; //Description of the xml
  var $_copyright = null; //Copyright
  var $_license = null; //License
  var $_email = null; //email of the autor
  var $_site = null; //site of the author
  //var $_createDate = null;

  function jsACL($file)
  {
    $this->_file = $file;
    $xmlFile = new JSimpleXML();
    if (!$xmlFile->loadFile('components/com_jcacl/xml/'.$this->_file))
    {
      return;
    }
    $this->_option = $xmlFile->document->_attributes['option'];
    foreach ($xmlFile->document->_children as $child)
    {
      if ($child->_name!='group')
      {
        $this->_info[$child->_name] = $child->_data; // Descriptions
      }
      else if ($child->_name=='group')
      {
        $groupName = $child->_attributes['name']; //Group Name
        $this->_groups[] = $groupName;

        if (count($child->_children)==0)
        $this->_items[$groupName] =null;

        $counter = 0;
        foreach($child->_children as $groupParams)
        {
          $this->_items[$groupName][$counter]['name'] = $groupParams->_data;
          $this->_items[$groupName][$counter]['attributes'] = $groupParams->_attributes;
          $counter++;
        }
      }
    }

    $this->_info['option'] = $this->_option;
    //$this->_createDate = $this->_info['createDate'];
    $this->_name = $this->_info['name'];
    $this->_author = $this->_info['author'];
    $this->_version = $this->_info['version'];
    $this->_email = $this->_info['email'];
    $this->_site = $this->_info['site'];
    $this->_license = $this->_info['license'];
    $this->_copyright = $this->_info['copyright'];
    $this->_description = $this->_info['description'];

  }

  function getGroupList()
  {
    return $this->_groups;
  }

  function getGroupItems($name)
  {
    return $this->items;
  }

  function getOption()
  {
    return $this->_option;
  }

  function getVersion()
  {
    return $this->_version;
  }

  function getName()
  {
    return $this->_name;
  }

  function getAuthor()
  {
    return  $this->_author;
  }

  function getDescription()
  {
    return $this->_description;
  }

  function getCopyright()
  {
    return $this->_copyrihgt;
  }

  function getLicense()
  {
    return $this->_license;
  }

  function getInfo()
  {
    $out['author'] = $this->getAuthor();
  }

  function printAll()
  {
    print $this->_file."<br>" ; //File to parse
    print "<pre>";
    print_r ($this->_groups); //list of the groups
    print_r ($this->_items); //array of items in the groups
    print_r ($this->_info); //all The info about the xml file
    print "</pre><br>";
    print $this->_name."<br>"; //name of the component
    print $this->_option."<br>"; //option i.e com_something
    print $this->_author."<br>"; //Author
    print $this->_version."<br>"; //version fo the
    print $this->_description."<br>"; //Description of the xml
    print $this->_copyright."<br>"; //Copyright
    print $this->_license."<br>"; //License
    print $this->_email."<br>"; //email of the autor
    print $this->_site."<br>"; //site of the author
  }
  /**
     * Get full info on the variable
     *
     * @param string $file
     * @param string $group
     * @param string $name
     * @return mixed
     */
  function getVariables($file, $group, $name)
  {
    $xmlFile = new JSimpleXML();
    if (!$xmlFile->loadFile('components/com_jcacl/xml/'.$file))
    {
      return 0;
    }
    foreach ($xmlFile->document->_children as $child)
    {
      if ($child->_name == 'group')
      {
        $allGroups[] = $child->_attributes['name'];
        if( $group == $child->_attributes['name'] )
        {
          foreach($child->_children as $groupParams)
          {
            if ($name == $groupParams->_data)
            $attributes[] = $groupParams->_attributes;
          }
        }
      }
    }
    if (count($attributes)>0)
    {
      $ret['allGroups'] = $allGroups;
      $ret['group'] = $group;
      $ret['varname'] = $name;
      $ret['attributes'] = $attributes;
      return $ret;
    }
    else
    {
      return 0;
    }
  }

  /**
    * function to change group of the variable
    * @param object $xmlFile
    * @param string $oldGroupName
    * @param string $newGroupName
    * @param string $variableName
    * @param array $attrs
    */
  function changeVarGroupName(&$xmlFile,$oldGroupName, $newGroupName, $variableName ,$attrs=array())
  {

    $children1=&$xmlFile->document->_children;
    if (count($attrs)>0)
    {
      foreach($attrs as $attr)
      {
        $attributes[$attr['key']] = $attr['value'];

      }
    }
    else
    {

      for ($j=0; $j<count($children1); $j++)
      {

        if ($children1[$j]->_name=='group' and $children1[$j]->_attributes['name']==$oldGroupName)
        {
          for($i=0; $i<count($children1[$j]->_children); $i++)
          {
            if ($children1[$j]->_children[$i]->_data==$variableName)
            {
              $attributes = $children1[$j]->_children[$i]->attributes();
            }
          }
        }
      }
    }

    for ($j=0; $j<count($children1); $j++)
    {
      if ($children1[$j]->_name=='group' and $children1[$j]->_attributes['name']==$oldGroupName)
      {
        for($i=0; $i<count($children1[$j]->_children); $i++)
        {
          if ($children1[$j]->_children[$i]->_data==$variableName)
          {
            $children1[$j]->removeChild($children1[$j]->_children[$i]);
          }
        }
      }
    }
     for ($j = 0 ; $j<count($children1); $j++)
    {
      if ($children1[$j]->_name == 'group' and $children1[$j]->_attributes['name']==$newGroupName)
      {

        if (jsACL::isVariabeExist($xmlFile, $variableName, $newGroupName))
        {

          for ($i=0; $i<count($children1[$j]->_children); $i++)
          {

            if ($children1[$j]->_children[$i]->_data==$variableName)
            {

              $num = count($children1[$j]->_children);
              $children1[$j]->removeChild($children1[$j]->_children[$i]);
              $children1[$j]->addChild('variable', $attributes);
              $children1[$j]->_children[($num-1)]->setData($variableName);
            }
          }
        }
        else
        {

          $num = count($children1[$j]->_children);
          $children1[$j]->addChild('variable', $attributes);
          $children1[$j]->_children[$num]->setData($variableName);
        }
      }
    }
  }

  /**
    * Enter description here...
    *
    * @param object $xmlFile
    * @param string $variableName
    * @param string $groupName
    * @param arrray $attrs
    */
  function changeVariableAttributes(&$xmlFile, $variableName, $groupName, $attrs)
  {
    //print "<pre>";
    // print_r($attrs);
    //print "</pre>";

    $document = &$xmlFile->document->_children;
    for($counter = 0; $counter<count($document); $counter++)
    {
      if ($document[$counter]->_name=='group' and $document[$counter]->_attributes['name']==$groupName)
      {
        for ($i=0; $i<count($document[$counter]->_children) ; $i++)
        {
          if ($document[$counter]->_children[$i]->_data == $variableName)
          {
            foreach ($attrs as $attr)
            {
              if ($attr['key']=='' and $attr['value']=='' and $attr['old']!='')
              {
                $todel = explode("::",$attr['old']);
                $document[$counter]->_children[$i]->removeAttribute($todel[0] );
              }
              else if ($attr['key']!='' and $attr['value']!='')
              {
                $document[$counter]->_children[$i]->addAttribute($attr['key'], $attr['value']);
              }
              else continue;
            }
          }
        }

      }
    }

  }
  /**
    * Create a group
    *
    * @param object $xmlFile
    * @param string $name name of the group
    */
  function createGroup(&$xmlFile, $name)
  {
    $xmlFile->document->addChild('group', array('name'=>$name));
  }

  /**
    * Delete a group
    *
    * @param object $xmlFile
    * @param string $group Name of the group to delete
    */
  function deleteGroups(&$xmlFile, $group)
  {

    for($i=0; $i<count($xmlFile->document->_children); $i++)
    {
      if ($xmlFile->document->_children[$i]->_attributes['name']==$group)
      {
        $xmlFile->document->removeChild($xmlFile->document->_children[$i]);
      }
    }

  }

  function deleteVars(&$xmlFile, $variableName, $groupName)
  {

    $children1 = &$xmlFile->document->_children;
    for ($j=0; $j<count($children1); $j++)
    {
      if ($children1[$j]->_name=='group' and $children1[$j]->_attributes['name']==$groupName)
      {
        for($i=0; $i<count($children1[$j]->_children); $i++)
        {
          if ($children1[$j]->_children[$i]->_data==$variableName)
          {
            $children1[$j]->removeChild($children1[$j]->_children[$i]);
          }
        }
      }
    }
  }

  /**
    * Adds variable into the XML file
    *
    * @param object $xmlFile
    * @param string $variable Name name of the new variable
    * @param string $groupName name of the group
    * @param array $attrs array of attributes
    */
  function addVariable(&$xmlFile, $variableName, $groupName, $attrs)
  {
    $set = false;
    if (count($attrs)>0){
      foreach($attrs as $attr)
      {
        $attributes[$attr['key']] = $attr['value'];

      }
    }
    else $attributes = array();
    $children1 = &$xmlFile->document->_children;

    for ($j=0; $j<count($children1); $j++)
    {
      if ($children1[$j]->_name=='group' and $children1[$j]->_attributes['name']==$groupName)
      {
        $num = count($children1[$j]->_children);
        if (count($attributes)>0)
        $children1[$j]->_children[count($children1[$j]->_children)] = $children1[$j]->addChild('variable', $attributes);
        else
        $children1[$j]->_children[count($children1[$j]->_children)] = $children1[$j]->addChild('variable');
        $children1[$j]->_children[$num]->setData($variableName);
        $set = true;
      }

    }
    if (!$set)
    {
      $this->createGroup($xmlFile, $groupName);
      $this->addVariable($xmlFile, $variableName, $groupName, $attrs);
    }


  }

  function changeDesc(&$xmlFile, $key, $value)
  {
    $children = &$xmlFile->document->_children;
    for($i = 0; $i<count($children); $i++)
    {
      if($children[$i]->_name==$key)
      {
        $children[$i]->_data = $value;
      }
    }
  }

  function changeGroupName(&$xmlFile, $oldName, $newName)
  {
    $children = &$xmlFile->document->_children;
    for ($j=0; $j<count($children); $j++)
    {
      if ($children[$j]->_name=='group' and $children[$j]->_attributes['name']==$oldName)
      {
        $children[$j]->_attributes['name']=$newName;
      }
    }
  }

  function isVariabeExist(&$xmlFile, $variableName, $groupName)
  {

    $children1 = &$xmlFile->document->_children;

    for ($i = 0; $i<count($children1); $i++)
    {
      if ($children1[$i]->_name=='group' and $children1[$i]->_attributes['name']==$groupName){
        $children2 = $children1[$i]->_children;
        for($j=0; $j<count($children2); $j++)
        {
          if ($children2[$j]->_data==$variableName)
          {return true;}
        }
      }
    }

    return false;
  }

  function copyVar(&$xmlFile, $groupName , $whereTo, $variableName)
  {

    $children1 = &$xmlFile->document->_children;
    $attributes = array();
    for ($j = 0; $j<count($children1); $j++)
    {
      if ($children1[$j]->_name == 'group' and $children1[$j]->_attributes['name'] == $groupName)
      {
        for($i=0; $i<count($children1[$j]->_children); $i++)
        {
          print $variableName;
          if ($children1[$j]->_children[$i]->_data==$variableName)
          {
            $attributes =$children1[$j]->_children[$i]->attributes();
            //print_R($attributes);
          }
        }
      }
    }

    for ($j = 0 ; $j<count($children1); $j++)
    {
      if ($children1[$j]->_name == 'group' and $children1[$j]->_attributes['name']==$whereTo)
      {

        if (jsACL::isVariabeExist($xmlFile, $variableName, $whereTo))
        {

          for ($i=0; $i<count($children1[$j]->children); $i++)
          {

            if ($children1[$j]->_children[$i]->_data==$variableName)
            {

              $num = count($children1[$j]->_children);

              $children1[$j]->removeChild($children1[$j]->_children[$i]);

              $children1[$j]->addChild('variable', $attributes);
              $children1[$j]->_children[($num-1)]->setData($variableName);
            }
          }
        }
        else
        {

          $num = count($children1[$j]->_children);
          $children1[$j]->addChild('variable', $attributes);
          $children1[$j]->_children[$num]->setData($variableName);
        }
      }
    }
  }

}

?>