<?php
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * @author Azamat Tokhtaev
 */
class jcACLModelUsers extends JModel
{
  var $xml_data = null;
  var $groups_data = null;
  var $oneXml = null;
  var $myGroup = null;
  var $blocked = null;
  var $users = null;

  function __construct()
	{
		parent::__construct();
	}


function getXml()
	{
	  if (empty($this->xml_data))
	  {
  	   jimport('joomla.filesystem.folder');
  	   require_once('components/com_jcacl/helpers/xml_parser.php');
       $files = JFolder::files('components/com_jcacl/xml','xml$', false, false);
       if (count($files)>0){
         foreach ($files as $file)
         {
            $this->xml_data[$file] = new jsACL($file);
         }
       }
	  }
    return $this->xml_data;
	}

	function getOneXml()
  {
    if (empty($this->oneXml))
    {
      $component = JRequest::getVar('value');
      require_once('components/com_jcacl/helpers/xml_parser.php');
      $this->oneXml = new jsACL($component);
    }
    return $this->oneXml;
  }

  function getUsers()
  {
    if (empty($this->users))
    {
      $and ='';
      $ids = JRequest::getVar('users');
      if (empty($ids))
      {
        $ids = JRequest::getVar('cid');
      }
      //print_r($ids);
      for ($i = 0; $i < count($ids); $i++)
      {
        if ($i == 0)
        {
          $and ="`id` = {$ids[$i]}";
        }
        else
        {
          $and.=" or `id` = {$ids[$i]}";
        }
      }
      $sql = "SELECT * FROM #__users where  ".$and;
      //print $sql;
      $this->_db->setQuery($sql);
      $this->users = $this->_db->loadObjectList();
      //print_r($this->users);
    }
    return $this->users;
  }

  function getBlocked()
  {
    if (empty($this->oneXML))
    {
      $this->getOneXml();
    }
    if(empty($this->blocked))
    {
      $sql = "SELECT * FROM #__jcacl_block_list where `option`='{$this->oneXml->_option}' and `user_id` <> 0";
      $this->_db->setQuery($sql);
      $this->blocked = $this->_db->loadObjectList();
      //print_r($this->blocked);
    }
    return $this->blocked;
  }

  function getMyGroup()
  {
    if (empty($this->myGroup))
    {
      $acl		=& JFactory::getACL();
      $myuser		=& JFactory::getUser();
      $myObjectID 	= $acl->get_object_id( 'users', $myuser->get('id'), 'ARO' );
  	  $myGroups 		= $acl->get_object_groups( $myObjectID, 'ARO' );
      $this->myGroup = $myGroups[0];
    }
    //var_dump($this->myGroup);
    return $this->myGroup;
  }
}
?>