<?php
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * @author Azamat Tokhtaev
 */
class jcACLModelComponents extends JModel
{
  var $xml_data = null;
  var $groups_data = null;
  var $oneXml = null;
  var $myGroup = null;
  var $blocked = null;
  var $variable = null;

  function __construct()
	{
		parent::__construct();
	}

	function getXml()
	{
	  if (empty($this->xml_data))
	  {
  	   jimport('joomla.filesystem.folder');
  	   require_once('components/com_jcacl/helpers/xml_parser.php');
       $files = JFolder::files('components/com_jcacl/xml','xml$', false, false);
       if (count($files)>0){
         foreach ($files as $file)
         {
            $this->xml_data[$file] = new jsACL($file);
         }
       }
	  }
    return $this->xml_data;
	}

	function getGroups()
	{
	  if (empty($this->groups_data))
	  {
      $acl = &JFactory::getACL();
      $gtree = $acl->get_group_children_tree( null, 'USERS', false );
      $this->groups_data = $gtree;
	  }
    return $this->groups_data;
	}
  function getOneXml()
  {
    if (empty($this->oneXml))
    {
      $component = JRequest::getVar('value');
      if (empty($component))
      {
        $component = JRequest::getVar('cid');
        $component = $component[0];
      }
      if (empty($component) or $component=='')
      {
        $component = JRequest::getVar('file');

      }
      require_once('components/com_jcacl/helpers/xml_parser.php');
      $this->oneXml = new jsACL($component);
    }
    return $this->oneXml;
  }

  function getMyGroup()
  {
    if (empty($this->myGroup))
    {
      $acl		=& JFactory::getACL();
      $myuser		=& JFactory::getUser();
      $myObjectID 	= $acl->get_object_id( 'users', $myuser->get('id'), 'ARO' );
  	  $myGroups 		= $acl->get_object_groups( $myObjectID, 'ARO' );
      $this->myGroup = $myGroups[0];
    }
    return $this->myGroup;
  }

  function getBlockedItems()
  {
    if (empty($this->oneXML))
    {
      $this->getOneXml();
    }
    if(empty($this->blocked))
    {
      $sql = "SELECT * FROM #__jcacl_block_list where `option`='{$this->oneXml->_option}'";
      $this->_db->setQuery($sql);
      $this->blocked = $this->_db->loadObjectList();
      //print "<pre>";
      //print_r($this->blocked);
      //print "</pre>";
    }
    return $this->blocked;
  }

  function getVariable()
  {
    if (empty($this->variable))
    {
      $file = JRequest::getVar('file');
      $vars = JRequest::getVar('variable');
      $var = $vars[0];
      require_once('components/com_jcacl/helpers/xml_parser.php');
      $arr = @explode('::', $var);
      $this->variable = jsACL::getVariables($file, $arr[0], $arr[1]);
    }
    return $this->variable;
  }

  function getVarsToMove()
  {
    $varsToMove = JRequest::getVar('variable');
    return $varsToMove;
  }

}
?>