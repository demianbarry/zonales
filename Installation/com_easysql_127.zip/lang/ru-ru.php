<?php
if (!(defined( '_VALID_MOS' ) || defined( '_JEXEC' ))) die( 'Restricted access1' );

define('_ES_COMMAND', 		'Команда: ');
define('_ES_TABLE', 		'Таблица: ');
define('_ES_DISPLAY_RECORDS', 	'Вывести строк: ');
define('_ES_EXECSQL', 		'Выполнить SQL');
define('_ES_EDIT', 		'Редактировать');
define('_ES_DELETE', 		'Удалить');
define('_ES_DETAILS', 		'Поля');
define('_ES_CSV_DELIMITER', 	';');
define('_ES_TOCSV', 		'Эксп. в CSV');
define('_ES_COPYRIGHT', 	'<br/><center>Компонент <a href="http://lurm.net/?other/easysql">EasySQL v.1.27</a> для Joomla<br/>Автор: <a href="http://lurm.net/">Serebro</a></center>');
define('_ES_DISPLAY_CROPSTRING','Обрезать длинные строки данных? ');
define('_ES_NO_CONFIG',         'Could not writable config file (%s)!');
define('_ES_DONE',              'Done!');


?>
