<?php
if (!(defined( '_VALID_MOS' ) || defined( '_JEXEC' ))) die( 'Restricted access1' );

define('_ES_COMMAND', 		'Command: ');
define('_ES_TABLE', 		'Table: ');
define('_ES_DISPLAY_RECORDS', 	'Display records: ');
define('_ES_EXECSQL', 		'Exec SQL');
define('_ES_EDIT', 		'Edit');
define('_ES_DELETE', 		'Delete');
define('_ES_DETAILS', 		'Details');
define('_ES_CSV_DELIMITER', 	';');
define('_ES_TOCSV', 		'To CSV');
define('_ES_COPYRIGHT', 	'<br/><center>Component <a href="http://lurm.net/en/?other/easysql">EasySQL v.1.27</a> for Joomla<br/>Author: <a href="http://lurm.net/">Serebro</a></center>');
define('_ES_DISPLAY_CROPSTRING','Crop long data strings? ');
define('_ES_NO_CONFIG',         'Could not writable config file (%s)!');
define('_ES_DONE',              'Done!');



?>
