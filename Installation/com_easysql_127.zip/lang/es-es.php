<?php
if (!(defined( '_VALID_MOS' ) || defined( '_JEXEC' ))) die( 'Restricted access1' );
// spanish.php by Sol�n C�ceres Moreno solca@bogotanos.net
defined( '_VALID_MOS' ) or die( 'Acceso Restringido' );
define('_ES_COMMAND',   'Comando: ');
define('_ES_TABLE',   'Tabla: ');
define('_ES_DISPLAY_RECORDS',  'Desplegar registros: ');
define('_ES_EXECSQL',   'Ejecutar SQL');
define('_ES_EDIT',   'Editar');
define('_ES_DELETE',   'Borrar');
define('_ES_DETAILS',   'Detalles');
define('_ES_CSV_DELIMITER',  ';');
define('_ES_TOCSV',   'To CSV');
define('_ES_COPYRIGHT',  '<br/><center>Component <a href="http://lurm.net/en/?other/easysql">EasySQL v.1.27</a> for Joomla<br/>Author: <a href="Serebro" target="_blank"> http://lurm.net/">Serebro</a></center>' );
define('_ES_DISPLAY_CROPSTRING','Crop long data strings? ');
define('_ES_NO_CONFIG',         'Could not writable config file (%s)!');
define('_ES_DONE',              'Done!');

?>