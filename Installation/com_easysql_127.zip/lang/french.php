<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

define('_ES_COMMAND', 		'Commande: ');
define('_ES_TABLE', 		'Table: ');
define('_ES_DISPLAY_RECORDS', 	'Afficher Enregistrements: ');
define('_ES_EXECSQL', 		'Ex�cuter SQL');
define('_ES_EDIT', 		'Editer');
define('_ES_DELETE', 		'Effacer');
define('_ES_DETAILS', 		'D�tails');
define('_ES_CSV_DELEMITER', 	';');
define('_ES_TOCSV', 		'Vers fichier CSV');
define('_ES_COPYRIGHT', 	'<br/><center>Composant <a href="http://lurm.net/en/?other/easysql">EasySQL v.1.23</a> pour Joomla<br/>Auteur: <a href="http://lurm.net/">Serebro</a></center>');
define('_ES_DISPLAY_CROPSTRING','Couper champs de donn�es trop long? ');
define('_ES_NO_CONFIG',         'Could not writable config file (%s)!');
define('_ES_DONE',              'Done!');

?>
