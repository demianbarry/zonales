<?php

?>
<p class="<?php echo $this->class ?>">
    <?php echo $this->message ?>
</p>
<a href="<?php echo $this->return ?>">
    <?php echo $this->returnmessage ?>
</a>