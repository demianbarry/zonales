Please consult the Windows Live ID Web Authentication SDK documentation 
for the PHP QuickStart Sample instructions:

http://go.microsoft.com/fwlink/?LinkID=91762
