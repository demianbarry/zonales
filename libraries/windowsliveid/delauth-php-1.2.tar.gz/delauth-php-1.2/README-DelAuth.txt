Please consult the Windows Live ID Delegated Authentication SDK documentation 
for the PHP QuickStart Sample instructions:

http://go.microsoft.com/fwlink/?LinkID=107420
