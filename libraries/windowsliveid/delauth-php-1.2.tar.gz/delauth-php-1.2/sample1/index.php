<?php

/** 
 * This is the main page of the first Delegated Authentication sample.  
 * It displays the link for granting consent as well as a user 
 * greeting.
 */

// Load common settings. For more information, see Settings.php.
include 'settings.php';

include '../lib/windowslivelogin.php';

// Initialize the WindowsLiveLogin module.
$wll = WindowsLiveLogin::initFromXml($KEYFILE);
$wll->setDebug($DEBUG);
//Get the consent URL for the specified offers.
$consenturl = $wll->getConsentUrl($OFFERS);

// If the raw consent token has been cached in a site cookie, attempt to
// process it and extract the consent token.
$message_html = "<p>Please <a href=\"$consenturl\">click here</a> to grant consent 
                 for this application to access your Windows Live data.</p>";

$token = null;
$cookie = @$_COOKIE[$COOKIE];
if ($cookie) {
    $token = $wll->processConsentToken($cookie);
}

if ($token && !$token->isValid()) {
    $token = null;
}

if ($token) {
    // Convert Unix epoch time stamp to user-friendly format.
    $expiry = $token->getExpiry();
    $expiry = date(DATE_RFC2822, $expiry);
    // Prepare the message to display the consent token contents.
    $message_html = <<<END
    <p>Consent token found! The following are its contents.</p>

    <table>
    <tr><td>Delegation token</td><td>{$token->getDelegationToken()}</td></tr>
    <tr><td>Refresh token</td><td>{$token->getRefreshToken()}</td></tr>
    <tr><td>Expiry</td><td>{$expiry}</td></tr>
    <tr><td>Offers</td><td>{$token->getOffersString()}</td></tr>
    <tr><td>Context</td><td>{$token->getContext()}</td></tr>
    <tr><td>Token</td><td>{$token->getToken()}</td></tr>
    </table>

    <p>
    Click <a href="{$HANDLER}?action=delauth">here</a> to remove the token
    from your session.
    </p>
END;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <title>Windows Live ID&trade; Web Delegated Authentication Sample</title>
    <?php echo $BODYSTYLE; ?>
  </head>
  <body><table width="320"><tr><td>
    <h1>Welcome to the PHP Sample for the Windows Live&trade; ID Delegated
    Authentication SDK</h1>

    <?php echo $message_html; ?>
  </td></tr></table></body>
</html>
