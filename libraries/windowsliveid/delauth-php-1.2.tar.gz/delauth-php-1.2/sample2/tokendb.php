<?php

/**
 This is a consent token "DB" for demo purposes only.  We strongly recommend
 that a more robust mechanism be used for real application use.
 */

class TokenDB
{
    private $_dbfile;

    public function __construct($dbfile)
    {
        $this->_dbfile = $dbfile;
    }

    public function getToken($id)
    {
        if (!$id) {
            return;
        }

        $db = dba_open($this->_dbfile, "r", "flatfile");
        if (!$db) {
            error_log("Error: Del Auth sample: Problem while reading the token database.");
            return;
        }

        $token = dba_fetch($id, $db);
        dba_close($db);
        return $token;
    }

    public function setToken($id, $token)
    {
        if (!$id) {
            return;
        }

        $db = dba_open($this->_dbfile, "c", "flatfile");
        if (!$db) {
            error_log("Error: Del Auth sample: Problem while writing the token database.");
            return;
        }

        if (!dba_replace($id, $token, $db) ) {
            error_log("Error: Del Auth sample: Problem while writing the token database.");
        }
        dba_close($db);
    }
}
?>
