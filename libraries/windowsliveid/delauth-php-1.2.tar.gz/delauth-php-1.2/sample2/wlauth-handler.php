<?php 

// This page handles the 'login', 'logout', 'clearcookie' and 'delauth'
// Web Authentication and Delegated Authentication actions. When you 
// create a Windows Live application, you must specify the URL of this 
// handler page.

// Load common settings.  For more information, see Settings.php.
include 'settings.php';

include '../lib/windowslivelogin.php';
include 'tokendb.php';

// Initialize the WindowsLiveLogin module.
$wll = WindowsLiveLogin::initFromXml($KEYFILE);
$wll->setDebug($DEBUG);

// Extract the 'action' parameter, if any, from the request.
$action = @$_REQUEST['action'];

// If action is 'logout', clear the login cookie and redirect to the
// logout page.
//
// If action is 'clearcookie', clear the login cookie and return a GIF
// as a response to signify success.
//
// If action is 'login', try to process sign-in. If the sign-in is  
// successful, cache the user token in a cookie and redirect to the  
// site's main page. If sign-in failed, clear the cookie and redirect 
// to the main page.
//
// If action is 'delauth', get user token from the cookie. Process the 
// consent token. If the consent token is valid, store the raw consent 
// token in persistent storage. Redirect to the site's main page.
switch ($action) {
    case 'logout':
        setcookie($WEBAUTHCOOKIE);
        header("Location: $LOGOUT");
        break;
    case "clearcookie":
        ob_start();
        setcookie($WEBAUTHCOOKIE);

        list($type, $response) = $wll->getClearCookieResponse();
        header("Content-Type: $type");
        print($response);

        ob_end_flush();
        break;
    case 'login':
        $user = $wll->processLogin($_REQUEST);
      
        if ($user) {
            if ($user->usePersistentCookie()) {
                setcookie($WEBAUTHCOOKIE, $user->getToken(), $COOKIETTL);
            }
            else {
                setcookie($WEBAUTHCOOKIE, $user->getToken());
            }
            header("Location: $LOGIN");
        }
        else {
            setcookie($WEBAUTHCOOKIE);
            header("Location: $LOGIN");
        }
        break;
    case 'delauth':
    $user = null;
    $logintoken = @$_COOKIE[$WEBAUTHCOOKIE];

    if ($logintoken) {
      $user = $wll->processToken($logintoken);
    }

    if ($user) {
      $consent = $wll->processConsent(@$_REQUEST);
      if ($consent && $consent->isValid()) {
        $tokens  = new TokenDB($TOKENDB);
        $tokens->setToken($user->getId(), $consent->getToken());
      }
    }
        header("Location: $LOGIN");
        break;
    default:
        header("Location: $LOGIN");
}

?>
