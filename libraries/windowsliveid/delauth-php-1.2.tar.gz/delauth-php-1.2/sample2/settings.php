<?php

// Specify true to log messages to Web server logs.
$DEBUG = false;

// Comma-delimited list of offers to be used.
$OFFERS = "Contacts.View";

// Application key file: store in an area that cannot be
// accessed from the Web.
$KEYFILE = '../DelAuth-Sample2.xml';

// Name of the writable SDBM file to use to store the raw consent token 
// to Token table.  Be aware that for the purposes of the sample, the 
// default value points to a temporary directory that is publically writable 
// by default on many installations.  This directory may be cleaned at any 
// time by system processes or an administrator.
$TOKENDB = '/var/tmp/delauth-php-sample-tokendb';

// Name of cookie to use to cache the user token obtained through Web 
// Authentication. If a persistent cookie is being used, COOKIETTL 
// determines its expiry time.
$WEBAUTHCOOKIE = 'webauthtoken';
$COOKIETTL = time() + (10 * 365 * 24 * 60 * 60);

// URL of Web Authentication sample index page.
$INDEX = 'index.php';

// Landing pages to use after processing login and logout respectively.
$LOGIN = $INDEX;
$LOGOUT = $INDEX;

// The location of the Web Authentication control. You should not have 
// to change this value.
$CONTROLURL = 'http://login.live.com/controls/WebAuth.htm';

// The CSS style string to pass in to the Web Authentication control.
$CONTROLSTYLE = urlencode('font-size: 10pt; font-family: verdana; background: white;');

// The CSS style to use for the page body.
$BODYSTYLE = <<<END
    <style type="text/css">
      table
      {
        font-family: verdana;
        font-size: 10pt;
        color: black;
        background-color: white;
      }
      h1
      {
        font-family: verdana;
        font-size: 10pt;
        font-weight: bold;
        color: #0070C0;
      }
    </style>
END;

?>
