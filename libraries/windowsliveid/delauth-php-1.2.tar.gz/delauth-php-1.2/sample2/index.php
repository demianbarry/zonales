<?php

/** 
 * This is the main page of the second Delegated Authentication sample.
 * It displays the Sign in/Sign out link as well as a user greeting.
 */

// Load common settings. For more information, see settings.php.
include 'settings.php';

include 'tokendb.php';
include '../lib/windowslivelogin.php';

// Initialize the WindowsLiveLogin module.
$wll = WindowsLiveLogin::initFromXml($KEYFILE);
$wll->setDebug($DEBUG);
$APPID = $wll->getAppId();

$login_html = "<p>This application does not know who you are!  Click the <b>Sign in</b> link above.</p>";
$consent_html = null;

// If the user token obtained from sign-in through Web Authentication 
// has been cached in a site cookie, attempt to process it and extract 
// the user ID.
$token = @$_COOKIE[$WEBAUTHCOOKIE];
$userid = null;
if ($token) {
    $user = $wll->processToken($token);
    if ($user) {
        $userid = $user->getId();
    }
}

// If the user ID is obtained successfully, prepare the message 
// to include the consent URL if a valid token is not present in the 
// persistent store; otherwise display the contents of the token.
if ($userid) {
    $login_html = "<p>Now this application knows that you are the user with ID = \"<b>$userid</b>\".</p>";
    
    $consenturl = $wll->getConsentUrl($OFFERS);
    $consent_html = "<p>Please <a href=\"$consenturl\">click here</a> to grant consent so that we may access your Windows Live data.</p>";

    // Attempt to get the raw consent token from persistent store for the 
    // current user ID.
    $tokens  = new TokenDB($TOKENDB);
    $token = $tokens->getToken($userid);
    
    $consenttoken = $wll->processConsentToken($token);
    
    // If a consent token is found and is stale, try to refresh it and store  
    // it in persistent storage.
    if ($consenttoken) {
        if (!$consenttoken->isValid()) {
            if ($consenttoken->refresh() && $consenttoken->isValid()) {
                $tokens->setToken($userid, $consenttoken->getToken());
            }
        }
    
        if ($consenttoken->isValid()) {
            // Convert Unix epoch time stamp to user-friendly format.
            $expiry = $consenttoken->getExpiry();
            $expiry = date(DATE_RFC2822, $expiry);
            //Prepare the message to display the consent token contents.
            $consent_html = <<<END
<p>Consent token found! The following are its contents..</p>

<table>
<tr><td>Delegation token</td><td>{$consenttoken->getDelegationToken()}</td></tr>
<tr><td>Refresh token</td><td>{$consenttoken->getRefreshToken()}</td></tr>
<tr><td>Expiry</td><td>{$expiry}</td></tr>
<tr><td>Offers</td><td>{$consenttoken->getOffersString()}</td></tr>
<tr><td>Context</td><td>{$consenttoken->getContext()}</td></tr>
<tr><td>Token</td><td>{$consenttoken->getToken()}</td></tr>
</table>
END;
        }   
    }
}

// This code embeds the Web Authentication control on your Web page 
// to display the appropriate application Sign in/Sign out link.
$control_html = <<<END
  <iframe 
    id="WebAuthControl" 
    name="WebAuthControl" 
    src="$CONTROLURL?appid=$APPID&style=$CONTROLSTYLE"
    width="80px"
    height="20px"
    marginwidth="0"
    marginheight="0"
    align="middle"
    frameborder="0"
    scrolling="no">
  </iframe>
END;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <title>Windows Live&trade; ID Delegated Authentication Sample 2</title>
    <?php echo $BODYSTYLE; ?>
  </head>
  <body><table width="320"><tr><td>
    <h1>Welcome to the second PHP sample for the Windows Live&trade; ID Delegated
    Authentication SDK</h1>

    <p>The text of the link below indicates whether you are signed in
    or not. If the link invites you to <b>Sign in</b>, you are not
    signed in yet. If it says <b>Sign out</b>, you are already signed
    in.</p>

    <?php echo $control_html; ?>

    <?php echo $login_html; ?>

    <?php echo $consent_html; ?>
  </td></tr></table></body>
</html>
