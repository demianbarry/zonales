package parser;


import java.io.PrintWriter;
import metadata.ZCrawling;


//import nl.msd.jdots.JD_Object;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author juanma
 */
public class Globals {
    public static ZCrawling zcrawling;
    public static PrintWriter out;
    public static Boolean siosi = false;
    public static Boolean nocriterios = false;
}
