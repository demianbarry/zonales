<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

require_once JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_alias' . DS . 'models' . DS . 'alias.php';

$aliasModel = new AliasModelAlias();
$data = $aliasModel->getData(true);

echo "<p/>$data->alias<p/>";
echo "<p/>$data->provider<p/>";
echo "<p/>$data->association_date<p/>";

?>
