<p><?php echo $this->aliasNotFoundMessage ?></p>
<p><?php echo $this->requestMessage ?></p>
<p></p>
<a href="<?php echo $this->urlLogin ?>"><?php echo $this->userMessage ?></a>
<p></p>
<a href="<?php echo $this->urlRegister ?>"><?php echo $this->notUserMessage ?></a>